import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:invo_models/invo_models.dart';
import 'package:newcall_center/blocs/customer.page.bloc.dart';
import 'package:newcall_center/services/reposiory.services.dart';
import 'package:newcall_center/utils/naviagtion.service.dart';

import '../models/branch.models.dart';
import '../services/order.services.dart';
import 'bloc.base.dart';

class HomePageBloc implements BlocBase {
  Property<List<Service>> services = Property([]);
  Employee allEmployee = Employee(id: "", name: "All Employees", email: "", passCode: "", MSR: "");
  Property<List<Employee>> employees = Property([]);
  Property<List<Branch>> branches = Property([]);

  Property<bool> updateFilter = Property(false);
  Property<Invoice?> invoice = Property(null);
  Property<List<InvoiceMini>> orders = Property([]);

  late Repository repository;

  String? selectedBranchId;
  String? selectedEmployeeId;
  String? selectedTicket;
  String? filter;

  HomePageBloc() {
    repository = GetIt.instance.get<Repository>();
    services.sink(repository.services);
    employees.sink(repository.employees);
    branches.sink(repository.branches);
    loadOrdersInvoiceMini();
  }

  @override
  void dispose() {
    // TODO: implement dispose
  }
  String telephone = "";
  void updateTelephone(String txt) {
    telephone = txt;
  }

  goToCustomerPage() {}

  void loadCustomer(BuildContext context, Service service) async {
    try {
      CustomerPageBloc customerBloc = await CustomerPageBloc.fromPhone(telephone, service);
      GetIt.instance.get<NavigationService>().goToCustomerPage(customerBloc);
    } catch (e) {
      print(e);
      _showAlertDialog(context);
      // show if server error
    }
  }

  void _showAlertDialog(BuildContext context) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('The number not correct'),
          content: const Text('Enter a valid phone number.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Confirm'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  go() {
    loadOrdersInvoiceMini();
  }

  getInvoice(String id) async {
    Invoice? invoiceTemp = await OrderService().getInvoice(id);
    invoice.sink(invoiceTemp);
    print(invoiceTemp.toString());
  }

  reset() {
    selectedEmployeeId = null;
    selectedBranchId = null;
    selectedTicket = null;
    filter = null;
    updateFilter.sink(true);
    // print(selectedEmployeeId! + ' ' + selectedBranchId! + ' ' + selectedTicket!);
  }

  loadOrdersInvoiceMini() async {
    List<InvoiceMini> loadedOrders = await OrderService().getOrders(selectedEmployeeId, selectedBranchId, filter);
    orders.sink(loadedOrders);
  }

  // (bool, bool) isPickupIsDelivery10(bool isPickup, bool isDelivery) {
  //   return (true, false);
  // }

  // (bool, bool) isPickupIsDelivery01() {
  //   return (false, true);
  // }

  // isPickupIsDelivery1(bool isPickup, bool isDelivery) {
  //   isPickup = true;
  //   isDelivery = false;
  //   return (42, "foobar");
  // }

  SelectedBranchId() {}
}

//  Future<HomePageBloc> loadSuggestion(String GroupId, String phoneNumber,
//     {selectMode = false, bool showPurchaseHistory = false}) async {
//   try {
//     List<dynamic>? suggestedList = await CustomerService().getSuggestion(GroupId, phoneNumber);
//     return CustomerPageBloc(suggestedList, selectMode, showPurchaseHistory);
//   } catch (e) {
//     // Handle the exception or propagate it further
//     throw Exception('Failed to load suggestion: $e');
//   }
// }