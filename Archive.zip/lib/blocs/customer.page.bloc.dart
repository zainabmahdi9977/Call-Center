import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:invo_models/invo_models.dart';
import 'package:newcall_center/blocs/bloc.base.dart';
import 'package:collection/collection.dart';
import 'package:newcall_center/blocs/orderPage/order.page.bloc.dart';
import 'package:newcall_center/utils/naviagtion.service.dart';
import '../../services/customer.services.dart';
import '../models/branch.models.dart';
import '../pages/HomePage/home.page.dart';

import '../services/reposiory.services.dart';

// class CustomerPageBloc {
//   CustomerPageBloc(String telephone) {
//     load(telephone);
//   }
//   void load(String telephone) async {
//     final customerService = CustomerService();
//     try {
//       final customer = await customerService.loadCustomer(telephone);
//       print(customer); // Do something with the loaded customer
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
// }

class CustomerPageBloc implements BlocBase {
  Property<bool> notesUpdated = Property(false);
  Property<bool> addressesUpdated = Property(false);
  Property<bool> onCustomerChange = Property(false);
  Property<CustomerAddress?> selectedAddress = Property(null);
  Property<List<InvoiceMini>> orders = Property([]);
  Property<Invoice?> order = Property(null);
  bool selectMode = false;
  bool showPurchaseHistory = false;

  Property<List<InvoiceMini>> unpaidOrders = Property([]);
  Property<List<InvoiceMini>> paidOrders = Property([]);

  Property<List<Branch>> branches = Property([]);
  late Repository repository;

  CustomerAddress? tempAddress;

  Customer customer;

  Map<String, dynamic> addressMap = {}; //temp value to save address

  double get totalSale {
    double total = 0;
    for (var element in orders.value) {
      total += element.total;
    }
    return total;
  }

  int get totalOrder {
    return orders.value.length;
  }

  double get avgOrder {
    return totalSale / totalOrder;
  }

  DeliveryAddresses get deliveryAddresses {
    // if (repository.preferences != null && repository.preferences!.deliveryAddresses != null)
    //   return repository.preferences!.deliveryAddresses!;
    return DeliveryAddresses();
  }

  List<AddressFormat> addressFormats = [];
  //change to property
  late Property<Service> service;
  List<Service> services = [];
  //constructor
  CustomerPageBloc(
    this.customer,
    this.selectMode,
    this.showPurchaseHistory,
    Service service,
  ) {
    // addressFormats = repository.preferences!.settings.addressFormat;
    PickUpBranches();
    this.service = Property(service);
    services = GetIt.instance.get<Repository>().services;
  }

  static Future<CustomerPageBloc> fromPhone(String phone, Service service, {selectMode = false, bool showPurchaseHistory = false}) async {
    Customer customer = await CustomerService().getCustomerByNumber(phone);
    customer ??= Customer(phone: phone);

    return CustomerPageBloc(customer, selectMode, showPurchaseHistory, service);
  }

  factory CustomerPageBloc.fromCustomer(
    Customer customer,
    Service service, {
    selectMode = false,
    bool showPurchaseHistory = false,
  }) {
    return CustomerPageBloc(
      customer,
      selectMode,
      showPurchaseHistory,
      service,
    );
  }

  List<String> getAddressesList(String addressKey, Map address) {
    List<String> addresses = [];
    switch (addressKey.toLowerCase()) {
      case "governorate":
        for (var element in deliveryAddresses.list) {
          if (element.Governorate.isNotEmpty && !addresses.contains(element.Governorate)) {
            addresses.add(element.Governorate);
          }
        }
        break;
      case "city":
        for (var element in deliveryAddresses.list) {
          if (element.City.isNotEmpty && !addresses.contains(element.City)) {
            addresses.add(element.City);
          }
        }
        break;
      case "block":
        List<Address> temp = deliveryAddresses.list;
        if (address['city'] != null && address['city'].isNotEmpty) {
          temp = deliveryAddresses.list.where((f) => f.City == address['city']).toList();
        }
        for (var element in temp) {
          if (element.Block.isNotEmpty && !addresses.contains(element.Block)) {
            addresses.add(element.Block);
          }
        }
        break;
      case "road":
        List<Address> temp = deliveryAddresses.list;
        if (address['block'] != null && address['block'].isNotEmpty) {
          temp = deliveryAddresses.list.where((f) => f.Block == address['block']).toList();
        }
        for (var element in temp) {
          if (element.Road.isNotEmpty && !addresses.contains(element.Road)) {
            addresses.add(element.Road);
          }
        }
        break;
      default:
    }

    return addresses;
  }

  PickUpBranches() {
    repository = GetIt.instance.get<Repository>();
    branches.sink(repository.branches);
  }

  setAddress(Map map, String key, String value) {
    if (map[key] == value) return;
    map[key] = value;
    try {
      switch (key) {
        case "city":
          Address? address = deliveryAddresses.list.firstWhereOrNull((f) => f.City == value);
          if (address != null) {
            map["governorate"] = address.Governorate;
            map["city"] = address.City;
            map["block"] = "";
            map["road"] = "";
          }

          break;
        case "block":
          Address? address = deliveryAddresses.list.firstWhereOrNull((f) => f.Block == value);
          if (address != null) {
            map["governorate"] = address.Governorate;
            map["city"] = address.City;
            map["block"] = address.Block;
            map["road"] = "";
          }
          break;
        case "road":
          Address? address = deliveryAddresses.list.firstWhereOrNull((f) => f.Road == value);
          if (address != null) {
            map["governorate"] = address.Governorate;
            map["city"] = address.City;
            map["block"] = address.Block;
            map["road"] = address.Road;
          }
          break;
        default:
      }
    } catch (e) {}
  }

  changeCustomer() async {
    // String phone = await GetIt.instance
    //     .get<DialogService>()
    //     .phoneDialog("Enter Phone Number");
    // Customer? customer =
    //     await GetIt.instance.get<ICustomerRepo>().getCustomerByPhone(phone);
    // if (customer != null) {
    //   this.customer = customer;
    //   onCustomerChange.sink(true);
    // }
  }

  changeService(Service selectedService) {
    service.sink(selectedService);
  }

  addAddress() {
    tempAddress = null;
    selectedAddress.sink(null);
    addressMap = CustomerAddress().toMap();
    selectedAddress.sink(CustomerAddress());
  }

  editAddress(CustomerAddress address) {
    tempAddress = address;
    addressMap = address.toMap();
    selectedAddress.sink(null);
    selectedAddress.sink(CustomerAddress.clone(address));
  }

  deleteAddress(CustomerAddress address) {
    tempAddress = null;
    selectedAddress.sink(null);
    customer.addresses.remove(address);
    addressesUpdated.sink(true);
  }

  addNote() async {
    // String? res =
    //     await GetIt.instance.get<DialogService>().noteDialog(initValue: "");
    // if (res != null) {
    //   customer.notes.insert(0, res);
    //   notesUpdated.sink(true);
    // }
  }

  editNote(String note) async {
    // String? res =
    //     await GetIt.instance.get<DialogService>().noteDialog(initValue: note);
    // if (res != null) {
    //   int index = customer.notes.indexOf(note);
    //   customer.notes.remove(note);
    //   customer.notes.insert(index, res);
    //   notesUpdated.sink(true);
    // }
  }

  deleteNote(String note) async {
    customer.notes.remove(note);
    notesUpdated.sink(true);
  }

  saveAddress() {
    if (selectedAddress.value != null) {
      if (tempAddress == null) {
        customer.addresses.add(selectedAddress.value!);
      } else {
        tempAddress!.copyfrom(selectedAddress.value!);
      }
      tempAddress = null;
      addressesUpdated.sink(true);
    }
  }

  loadPurchaseHistory({bool reload = false}) async {
    // if (orders.value.isEmpty || reload) {
    //   orders.sink(await GetIt.instance.get<IInvoiceRepo>().getInvoicesByCustomer(customer.id));
    // }
  }

  String? validatePhoneNumber() {
    if (customer.phone.isEmpty) {
      return 'Please enter customer phone';
    }

    // String countryCode = repository.preferences!.settings.countryCode;
    // List<String> prefix = repository.preferences!.settings.phonePrefix;
    // int phoneLength = repository.preferences!.settings.phoneLength;
    // String phoneRegExp = repository.preferences!.settings.phoneRegExp;
    // if (phoneRegExp == "") {
    //   phoneRegExp = "\\d";
    // }

    // String temp = "";
    // for (var element in prefix) {
    //   temp += "$element\\d{${phoneLength - element.length}}|";
    // }

    // if (temp == "") {
    //   temp = "\\d{$phoneLength}";
    // } else {
    //   temp = temp.substring(0, temp.length - 1);
    // }

    // print(r"((\+|00){0,1}" + countryCode + "){0,1}(" + temp + ")");
    // print(customer.phone);
    // RegExp exp = RegExp(phoneRegExp);
    // Iterable<RegExpMatch> matchs = exp.allMatches(customer.phone);
    // if (matchs.length != 1) {
    //   return 'invalid phone number';
    // } else {
    //   RegExpMatch x = matchs.first;
    //   print(x.group(0));
    //   if (x.group(0) != customer.phone) {
    //     return 'invalid phone number';
    //   }
    // }
    return null;
  }

  selectInvoice(InvoiceMini invoice) async {
    if (order.value != null) {
      if (order.value!.id == invoice.id) {
        return;
      }
    }

    for (var element in orders.value) {
      element.isSelected = false;
    }
    invoice.isSelected = true;

    dynamic temp = orders.value;
    orders.sink([]);
    orders.sink(temp);

    // Invoice? fullInvoice = await GetIt.instance.get<IInvoiceRepo>().getInvoiceById(invoice.id);
    // if (order.value != null) {
    //   order.value!.dispose();
    // }
    // order.sink(fullInvoice);
  }

  reOrder() async {
    // if (!await Privilege().checkLogin(Security.reOrder)) return;

    // if (order.value == null) return;
    // Invoice invoice = Invoice.fromInvoice(order.value!);
    // invoice.id = "";
    // invoice.invoiceNumber = "";
    // invoice.refrenceNumber = "";
    // invoice.terminalId = GetIt.instance.get<Repository>().terminal!.id;
    // invoice.createdAt = DateTime.now();
    // for (var line in invoice.lines) {
    //   line.id = "";
    // }
    // invoice.payments = [];
    // GetIt.instance.get<NavigationService>().goBack(null);
    // GetIt.instance.get<NavigationService>().goToOrderPage(OrderPageBloc.editOrder(invoice));
  }

  editOrder() {
    // InvoiceBloc().editOrder(order.value);
  }

  returnInvoice() async {
    // bool res = await InvoiceBloc().returnOrder(order.value);
    // if (res) {
    //   loadPurchaseHistory(reload: true);
    //   order.sink(null);
    // }
  }

  voidTicket() async {
    // bool res = await InvoiceBloc().voidOrder(order.value);
    // if (res) {
    //   loadPurchaseHistory(reload: true);
    //   order.sink(null);
    // }
  }

  showDiscountOrder() async {
    // bool res = await InvoiceBloc().discountOrder(order.value);
    // order.sink(null);
  }

  showSurchargeOrder() async {
    // bool res = await InvoiceBloc().surchargeOrder(order.value);
    // order.sink(null);
  }

  void selectBranch(Branch branch) {
    OrderPageBloc orderPageBloc = OrderPageBloc.newOrder(service.value, branch);
    GetIt.instance.get<NavigationService>().goToOrderPage(orderPageBloc);
  }

  saveCustomer() async {
    // String? validate = Validation().validatePhone(customer.phone);

    // if (validate != null) {
    //   bool res = await GetIt.instance
    //       .get<DialogService>()
    //       .confirmationDialog("Phone Validation", "$validate do you want to procceed?");
    //   if (!res) return;
    // }
    // GetIt.instance.get<DialogService>().showLoading();
    // try {
    //   await GetIt.instance
    //       .get<ICustomerRepo>()
    //       .saveCustomer(customer)
    //       .timeout(Duration(seconds: TimeoutDuration.duration));

    //   //select first address if nothing is selected
    //   if (customer.addresses.where((element) => element.isSelected).isEmpty) {
    //     if (customer.addresses.isNotEmpty) customer.addresses.first.isSelected = true;
    //   }

    //   await GetIt.instance.get<NavigationService>().goBack(customer);
    // } on TimeoutException {
    //   GetIt.instance.get<DialogService>().showToastMessage("No Internet Connection");
    // } finally {
    //   GetIt.instance.get<DialogService>().hideLoading();
    // }
  }

  cancel() async {
    // await GetIt.instance.get<NavigationService>().goBack(null);
  }

  @override
  void dispose() {
    notesUpdated.dispose();
    selectedAddress.dispose();
    addressesUpdated.dispose();
    onCustomerChange.dispose();
    orders.dispose();
    order.dispose();

    unpaidOrders.dispose();
    paidOrders.dispose();
    // TODO: implement dispose
  }
}
