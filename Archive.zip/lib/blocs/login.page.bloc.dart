import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:invo_models/invo_models.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/login.services.dart';
import '../utils/naviagtion.service.dart';

class LoginPageBloc {
  Property<String> errorMsg = Property("");

  String email = "";
  String password = "";

  dynamic focusNode = FocusNode();

  //String email, String password
  Future<bool> login() async {
    //Validation
    //login to server
    bool res = await LoginServices().checkLogin(email, password);
    if (res) {
      print('true');
      return true;
    } else {
      errorMsg.sink("Invalid email and password!");
      return false;
    }
    //Show error if exists

    //navigate route To Main page
  }

  Future<bool> isTokenValid() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    // bool tokenBool = prefs.containsKey("token");
    if (token != null) {
      return false;
    }

    return false;

    //check token; if exists

    //navigate to main page
  }
}
