class RouteConstants {
  static const String homeRouteName = 'home';
  static const String loginRouteName = 'login';
  static const String customerRouteName = 'customer';
  static const String orderRouteName = 'order';
  static const String mainRouteName = 'main';
}
