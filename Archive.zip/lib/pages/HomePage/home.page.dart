import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:invo_5_widget/invo_5_widget.dart';
import 'package:invo_models/invo_models.dart';
import 'package:newcall_center/blocs/home.page.bloc.dart';
import 'package:resize/resize.dart';

import '../../models/branch.models.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late HomePageBloc bloc;
  late TabController _tabController;

  final ScrollController _optionsController = ScrollController();
  // final _key = GlobalKey();

  late FocusNode focus;
  // late RecallPageBloc bloc;

  var tickets = <String>[
    "New",
    "Sent",
    "Voided"
  ];

  String vType = "grid";
  final StreamController<String> vTypeController = StreamController<String>.broadcast();

  double firstCol = 332;
  double keyBtnH = 100;

  bool isPickup = false;
  bool isDelivery = false;

  @override
  void initState() {
    super.initState();
    // bloc = widget.bloc;
    bloc = HomePageBloc();
    focus = FocusNode();

    firstCol = 322.w;
    keyBtnH = ((firstCol - 40.w) / 3);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
    _optionsController.dispose();
    // bloc.dispose();
  }

// This function is trggered somehow after build() called
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 15.h, horizontal: 15.w),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(
                    width: firstCol,
                    child: StreamBuilder(
                      // stream: bloc.orderState.stream,
                      stream: null,
                      initialData: null,
                      builder: (BuildContext context, AsyncSnapshot snapshot) {
                        // if (bloc.orderState.value is OrderIsLoaded) {
                        // OrderIsLoaded state = snapshot.data;
                        if (bloc.invoice.value != null) {
                          return Ticket(
                            firstCol,
                            key: GlobalKey(),
                            invoice: bloc.invoice.value!,
                            // invoice: state.invoice,
                            expandedTicket: () {
                              // bloc.expandedTicket();
                            },
                          );
                        }

                        return Container(
                          // margin: EdgeInsets.symmetric(horizontal: 5.w),
                          padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(15.r), color: WidgetUtilts.currentSkin.bgColor),
                          child: Stack(
                            fit: StackFit.expand,
                            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              RepaintBoundary(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    KeyPad(
                                      (txt) {
                                        bloc.updateTelephone(txt);
                                        focus.requestFocus();
                                      },
                                      keyHeight: keyBtnH,
                                      keypadType: KeyPadType.number,
                                      light: false,
                                    ),
                                    // StreamBuilder(
                                    //     stream: bloc.telephoneErrorMsg.stream,
                                    //     builder: (context, snapshot) {
                                    //       if (bloc.telephoneErrorMsg.value ==
                                    //           null) {
                                    //         return SizedBox(
                                    //           height: 10.h,
                                    //         );
                                    //       } else {
                                    //         return SizedBox(
                                    //           height: 40.h,
                                    //           child: Center(
                                    //             child: Text(
                                    //               bloc.telephoneErrorMsg.value!,
                                    //               style: const TextStyle(
                                    //                 color: Colors.red,
                                    //                 fontSize: 20,
                                    //                 fontWeight: FontWeight.bold,
                                    //               ),
                                    //             ),
                                    //           ),
                                    //         );
                                    //       }
                                    //     }),
                                    // StreamBuilder<Object>(
                                    //     stream: null,
                                    //     builder: (context, snapshot) {
                                    //       return Container(
                                    //         margin: EdgeInsets.symmetric(
                                    //             vertical: 9.h),
                                    //         height: 70.h,
                                    //         child: OptionButton(
                                    //           "Enter".tr(),
                                    //           fontSize: 22.sp,
                                    //           margin:
                                    //               EdgeInsets.only(top: 10.h),
                                    //           onTap: () async {
                                    //             bloc.loadCustomer();
                                    //             // CustomerPageBloc().load();

                                    //             // bloc.telephoneEnter();
                                    //           },
                                    //           // disabled:
                                    //           //     bloc.telephone.value.isEmpty
                                    //           //         ? true
                                    //           //         : false,
                                    //         ),
                                    //       );
                                    //     }),
                                  ],
                                ),
                              ),
                              RepaintBoundary(
                                child: Align(
                                  //Delivery or pickup
                                  alignment: Alignment.bottomCenter,
                                  child: SizedBox(
                                    height: 120.h,
                                    child: StreamBuilder(
                                        stream: bloc.services.stream,
                                        initialData: const [],
                                        builder: (context, snapshot) {
                                          return GridView.builder(
                                            itemCount: bloc.services.value.length,
                                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisSpacing: 5,
                                              crossAxisSpacing: 5,
                                              childAspectRatio: 2.3,
                                            ),
                                            itemBuilder: (context, index) => SizedBox(
                                              height: 70.h,
                                              child: OptionButton(
                                                bloc.services.value[index].name,
                                                fontSize: 22.sp,
                                                margin: EdgeInsets.only(bottom: 10.h),
                                                onTap: () {
                                                  bloc.loadCustomer(context, bloc.services.value[index]);

                                                  // Navigator.of(context).push(
                                                  //   MaterialPageRoute<void>(
                                                  //     builder: (BuildContext
                                                  //             context) =>
                                                  //         const CustomerPage(),
                                                  //   ),
                                                  // );
                                                  // bloc.showCustomersList();
                                                },
                                                // disabled: bloc.telephone
                                                //         .value.isNotEmpty
                                                //     ? true
                                                //     : false,
                                              ),
                                            ),
                                          );
                                        }),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                        // } else if (bloc.orderState.value is OrderIsHidden) {
                        //   if (bloc.closeOrdersOnly) {
                        //     return const SizedBox();
                        //   }
                        //   return Container(
                        //     // margin: EdgeInsets.symmetric(horizontal: 5.w),
                        //     padding: EdgeInsets.symmetric(
                        //         vertical: 10.h, horizontal: 10.w),
                        //     decoration: BoxDecoration(
                        //         borderRadius: BorderRadius.circular(15.r),
                        //         color: WidgetUtilts.currentSkin.bgColor),
                        //     child: Stack(
                        //       fit: StackFit.expand,
                        //       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //       children: [
                        //         RepaintBoundary(
                        //           child: Column(
                        //             crossAxisAlignment:
                        //                 CrossAxisAlignment.stretch,
                        //             children: [
                        //               KeyPad(
                        //                 (txt) {
                        //                   bloc.updateTelephone(txt);
                        //                   focus.requestFocus();
                        //                 },
                        //                 keyHeight: keyBtnH,
                        //                 keypadType: KeyPadType.number,
                        //                 light: false,
                        //               ),
                        //               StreamBuilder(
                        //                   stream: bloc.telephoneErrorMsg.stream,
                        //                   builder: (context, snapshot) {
                        //                     if (bloc.telephoneErrorMsg.value ==
                        //                         null) {
                        //                       return SizedBox(
                        //                         height: 10.h,
                        //                       );
                        //                     } else {
                        //                       return SizedBox(
                        //                         height: 40.h,
                        //                         child: Center(
                        //                           child: Text(
                        //                             bloc.telephoneErrorMsg
                        //                                 .value!,
                        //                             style: const TextStyle(
                        //                               color: Colors.red,
                        //                               fontSize: 20,
                        //                               fontWeight:
                        //                                   FontWeight.bold,
                        //                             ),
                        //                           ),
                        //                         ),
                        //                       );
                        //                     }
                        //                   }),
                        //               StreamBuilder<Object>(
                        //                   stream: bloc.telephone.stream,
                        //                   builder: (context, snapshot) {
                        //                     return SizedBox(
                        //                       height: 70.h,
                        //                       child: OptionButton(
                        //                         "Enter".tr(),
                        //                         fontSize: 22.sp,
                        //                         margin:
                        //                             EdgeInsets.only(top: 10.h),
                        //                         onTap: () {
                        //                           bloc.telephoneEnter();
                        //                         },
                        //                         disabled:
                        //                             bloc.telephone.value.isEmpty
                        //                                 ? true
                        //                                 : false,
                        //                       ),
                        //                     );
                        //                   }),
                        //             ],
                        //           ),
                        //         ),
                        //         RepaintBoundary(
                        //           child: Align(
                        //             alignment: Alignment.bottomCenter,
                        //             child: SizedBox(
                        //               height: 150.h,
                        //               child: StreamBuilder(
                        //                   stream: bloc.telephone.stream,
                        //                   builder: (context, snapshot) {
                        //                     return Column(
                        //                         crossAxisAlignment:
                        //                             CrossAxisAlignment.stretch,
                        //                         children: [
                        //                           SizedBox(
                        //                             height: 70.h,
                        //                             child: OptionButton(
                        //                               "Search Customer".tr(),
                        //                               fontSize: 22.sp,
                        //                               margin: EdgeInsets.only(
                        //                                   bottom: 10.h),
                        //                               onTap: () {
                        //                                 bloc.showCustomersList();
                        //                               },
                        //                               disabled: bloc.telephone
                        //                                       .value.isNotEmpty
                        //                                   ? true
                        //                                   : false,
                        //                             ),
                        //                           ),
                        //                           SizedBox(
                        //                             height: 10.h,
                        //                           ),
                        //                           SizedBox(
                        //                             height: 70.h,
                        //                             child: OptionButton(
                        //                               bloc.selectedService.value
                        //                                           .type ==
                        //                                       "Delivery"
                        //                                   ? "Take Order First"
                        //                                       .tr()
                        //                                   : "Walk In Customer"
                        //                                       .tr(),
                        //                               fontSize: 22.sp,
                        //                               margin:
                        //                                   const EdgeInsets.only(
                        //                                       bottom: 0),
                        //                               onTap: () {
                        //                                 bloc.takeOrderFirst();
                        //                               },
                        //                               disabled: bloc.telephone
                        //                                       .value.isNotEmpty
                        //                                   ? true
                        //                                   : false,
                        //                             ),
                        //                           ),
                        //                         ]);
                        //                   }),
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   );
                        // } else if (bloc.orderState.value is MultiSelection) {
                        //   List<InvoiceMini> orders =
                        //       (bloc.orderState.value as MultiSelection).orders;
                        //   double total = 0;
                        //   double balance = 0;
                        //   for (var element in orders) {
                        //     total += element.total;
                        //     balance += element.balance;
                        //   }
                        //   return Container(
                        //     decoration: BoxDecoration(
                        //         color: Colors.white,
                        //         border: Border.all(
                        //             width: 2,
                        //             color:
                        //                 WidgetUtilts.currentSkin.primaryColor),
                        //         borderRadius: BorderRadius.circular(15.r)),
                        //     child: Column(
                        //       children: [
                        //         Expanded(
                        //           child: ClipRRect(
                        //             borderRadius: BorderRadius.only(
                        //               topRight: Radius.circular(13.r),
                        //               topLeft: Radius.circular(13.r),
                        //             ),
                        //             child: ListView.builder(
                        //               itemCount: orders.length,
                        //               itemBuilder: (ctx, index) {
                        //                 return Container(
                        //                   decoration: BoxDecoration(
                        //                     color: Colors.white,
                        //                     border: Border.all(
                        //                         width: 1.w,
                        //                         color: const Color(0xFFDFECFF)),
                        //                   ),
                        //                   padding: EdgeInsets.symmetric(
                        //                       horizontal: 10.w, vertical: 5.h),
                        //                   child: Column(
                        //                     children: [
                        //                       Row(
                        //                         mainAxisAlignment:
                        //                             MainAxisAlignment
                        //                                 .spaceBetween,
                        //                         children: [
                        //                           Row(
                        //                             children: [
                        //                               Text(
                        //                                 "${"Order".tr()}# ",
                        //                                 style: const TextStyle(
                        //                                     fontWeight:
                        //                                         FontWeight.bold,
                        //                                     color: Color(
                        //                                         0xFF005BD2)),
                        //                               ),
                        //                               Text(
                        //                                   orders[index]
                        //                                           .invoiceNumber ??
                        //                                       "-",
                        //                                   style: const TextStyle(
                        //                                       color: Color(
                        //                                           0xFF005BD2))),
                        //                             ],
                        //                           ),
                        //                           Row(
                        //                             children: [
                        //                               Text(
                        //                                 "${"Ref#".tr()} ",
                        //                                 style: const TextStyle(
                        //                                     fontWeight:
                        //                                         FontWeight.bold,
                        //                                     color: Color(
                        //                                         0xFF005BD2)),
                        //                               ),
                        //                               Text(
                        //                                   orders[index]
                        //                                       .refrenceNumber,
                        //                                   style: const TextStyle(
                        //                                       color: Color(
                        //                                           0xFF005BD2))),
                        //                             ],
                        //                           ),
                        //                         ],
                        //                       ),
                        //                       SizedBox(
                        //                         height: 5.h,
                        //                       ),
                        //                       Row(
                        //                         mainAxisAlignment:
                        //                             MainAxisAlignment
                        //                                 .spaceBetween,
                        //                         children: [
                        //                           Expanded(
                        //                             child: Row(
                        //                               mainAxisSize:
                        //                                   MainAxisSize.min,
                        //                               children: [
                        //                                 Flexible(
                        //                                   child: ConstrainedBox(
                        //                                     constraints:
                        //                                         const BoxConstraints(
                        //                                             minWidth:
                        //                                                 30,
                        //                                             maxWidth:
                        //                                                 40),
                        //                                     child: Text(
                        //                                       maxLines: 2,
                        //                                       "Total".tr(),
                        //                                       style: const TextStyle(
                        //                                           height: 1,
                        //                                           fontWeight:
                        //                                               FontWeight
                        //                                                   .bold,
                        //                                           color: Color(
                        //                                               0xFF005BD2)),
                        //                                     ),
                        //                                   ),
                        //                                 ),
                        //                                 Text(
                        //                                     ": ${orders[index].total.toCurrency()}",
                        //                                     style: const TextStyle(
                        //                                         height: 1,
                        //                                         color: Color(
                        //                                             0xFF005BD2))),
                        //                               ],
                        //                             ),
                        //                           ),
                        //                           Row(
                        //                             children: [
                        //                               Text(
                        //                                 '${"Balance".tr()}: ',
                        //                                 style: const TextStyle(
                        //                                     height: 1,
                        //                                     fontWeight:
                        //                                         FontWeight.bold,
                        //                                     color: Color(
                        //                                         0xFF005BD2)),
                        //                               ),
                        //                               Text(
                        //                                   orders[index]
                        //                                       .balance
                        //                                       .toCurrency(),
                        //                                   style: const TextStyle(
                        //                                       height: 1,
                        //                                       color: Color(
                        //                                           0xFF005BD2))),
                        //                             ],
                        //                           ),
                        //                         ],
                        //                       ),
                        //                     ],
                        //                   ),
                        //                 );
                        //               },
                        //             ),
                        //           ),
                        //         ),
                        //         Container(
                        //           decoration: BoxDecoration(
                        //               color: const Color(0xFF005BD2),
                        //               border: Border.all(
                        //                   width: 1.w,
                        //                   color: const Color(0xFF005BD2)),
                        //               borderRadius: BorderRadius.only(
                        //                 bottomRight: Radius.circular(13.r),
                        //                 bottomLeft: Radius.circular(13.r),
                        //               )),
                        //           padding: EdgeInsets.symmetric(
                        //               horizontal: 10.w, vertical: 5.h),
                        //           child: Column(
                        //             children: [
                        //               Row(
                        //                 mainAxisAlignment:
                        //                     MainAxisAlignment.spaceBetween,
                        //                 children: [
                        //                   Text(
                        //                     "${"Total".tr()}: ",
                        //                     style: const TextStyle(
                        //                         fontWeight: FontWeight.bold,
                        //                         color: Colors.white),
                        //                   ),
                        //                   Row(
                        //                     children: [
                        //                       Text(
                        //                         total.toCurrency(),
                        //                         style: const TextStyle(
                        //                             color: Colors.white),
                        //                       ),
                        //                     ],
                        //                   ),
                        //                 ],
                        //               ),
                        //               Row(
                        //                 mainAxisAlignment:
                        //                     MainAxisAlignment.spaceBetween,
                        //                 children: [
                        //                   Text(
                        //                     "${"Balance".tr()}: ",
                        //                     style: const TextStyle(
                        //                         fontWeight: FontWeight.bold,
                        //                         color: Colors.white),
                        //                   ),
                        //                   Row(
                        //                     children: [
                        //                       Text(
                        //                         balance.toCurrency(),
                        //                         style: const TextStyle(
                        //                             color: Colors.white),
                        //                       ),
                        //                     ],
                        //                   ),
                        //                 ],
                        //               ),
                        //             ],
                        //           ),
                        //         )
                        //       ],
                        //     ),
                        //   );
                        // } else {
                        //   return const SizedBox();
                        // }
                      },
                    ),
                  ),
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 7.0),
                            child: SizedBox(
                              height: 50.h,
                              child: StreamBuilder(
                                  stream: bloc.updateFilter.stream,
                                  builder: (context, snapshot) {
                                    return Row(
                                      // scrollDirection: Axis.horizontal,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.symmetric(horizontal: 2.w),
                                          child: SizedBox(
                                            width: 280.w,
                                            child: DropDownMenu<Employee>(
                                              [
                                                bloc.allEmployee,
                                                ...bloc.employees.value,
                                              ].map<DropdownMenuItem<Employee>>((Employee value) {
                                                return DropdownMenuItem<Employee>(
                                                  value: value,
                                                  child: Text(
                                                    value.name,
                                                    style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                  ),
                                                );
                                              }).toList(),
                                              selectedValue: bloc.allEmployee,
                                              iconColor: const Color.fromRGBO(146, 146, 146, 1),
                                              color: const Color.fromRGBO(255, 255, 255, 1),
                                              borderColor: const Color.fromRGBO(215, 215, 215, 1),
                                              hint: 'Select Servers',
                                              onChanged: (employee) {
                                                if (employee != null) {
                                                  bloc.selectedEmployeeId = employee.id;
                                                } else {
                                                  bloc.selectedEmployeeId = null;
                                                }
                                              },
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(horizontal: 2.w),
                                          child: SizedBox(
                                            width: 280.w,
                                            child: DropDownMenu<String?>(
                                              [
                                                DropdownMenuItem<String?>(
                                                  value: null,
                                                  child: Text(
                                                    "All Branches",
                                                    style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                  ),
                                                ),
                                                ...bloc.branches.value.map<DropdownMenuItem<String?>>((Branch value) {
                                                  return DropdownMenuItem<String?>(
                                                    value: value.id,
                                                    child: Text(
                                                      value.name,
                                                      style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                    ),
                                                  );
                                                }).toList()
                                              ],
                                              selectedValue: bloc.selectedBranchId,
                                              iconColor: const Color.fromRGBO(146, 146, 146, 1),
                                              color: const Color.fromRGBO(255, 255, 255, 1),
                                              borderColor: const Color.fromRGBO(215, 215, 215, 1),
                                              hint: 'Select Branches',
                                              onChanged: (branchId) {
                                                bloc.selectedBranchId = branchId;
                                                print(branchId);
                                              },
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(horizontal: 2.w),
                                          child: SizedBox(
                                            width: 280.w,
                                            child: DropDownMenu<String?>([
                                              DropdownMenuItem<String?>(
                                                value: null,
                                                child: Text(
                                                  "All Tickets",
                                                  style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                ),
                                              ),
                                              ...tickets.map<DropdownMenuItem<String>>((String value) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(
                                                    value,
                                                    style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                  ),
                                                );
                                              }).toList(),
                                            ], selectedValue: bloc.selectedTicket, iconColor: const Color.fromRGBO(146, 146, 146, 1), color: const Color.fromRGBO(255, 255, 255, 1), borderColor: const Color.fromRGBO(215, 215, 215, 1), hint: 'New/Sent', onChanged: (ticket) {
                                              bloc.selectedTicket = ticket;
                                            }),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(horizontal: 2.w),
                                          child: SizedBox(
                                              width: 380.w,
                                              height: 70.h,
                                              child: CustomTextField(
                                                  hint: "Filter tickets",
                                                  callback: (valure) {
                                                    bloc.filter = valure;
                                                  })),
                                        ),
                                      ],
                                    );
                                  }),
                            ),
                          ),
                          SizedBox(
                            height: 50.h,
                            child: Row(
                              children: [
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 5.w),
                                  child: ExtraModifierButton(
                                    "GO",
                                    fontSize: 23.sp,
                                    padding: EdgeInsets.symmetric(horizontal: 32.w),
                                    onTap: () {
                                      bloc.go();
                                    },
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 3.w),
                                  child: ExtraModifierButton(
                                    "Reset",
                                    fontSize: 23.sp,
                                    padding: EdgeInsets.symmetric(horizontal: 32.w),
                                    onTap: () {
                                      bloc.reset();
                                    },
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      Expanded(
                          child: Container(
                              margin: EdgeInsets.only(top: 15.h),
                              padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
                              decoration: BoxDecoration(
                                  // border:
                                  //     Border.all(width: 1, color: Color.fromRGBO(0, 0, 0, 0.03)),
                                  // color: Color.fromRGBO(0, 0, 0, 0.03),
                                  borderRadius: BorderRadius.circular(15.r)),
                              child: StreamBuilder(
                                  stream: bloc.orders.stream,
                                  initialData: const [],
                                  builder: (context, snapshot) {
                                    return GridViewOrders(
                                        crossAxisCount: 5,
                                        orders: bloc.orders.value,
                                        onTab: (order) {
                                          bloc.getInvoice(order.id);

                                          // bloc.selectInvoice(order);
                                        });
                                  })))
                    ],
                  ))
                ],
              ),
            ),
          ),
          //Footer
          // Container(
          //   height: 80.h,
          //   padding: EdgeInsets.symmetric(horizontal: 30.w),
          //   decoration: BoxDecoration(
          //     gradient: WidgetUtilts.currentSkin.actionBar,
          //   ),
          //   // child: Row(
          //   //   children: [
          //   //     SizedBox(
          //   //       width: 20.w,
          //   //     ),
          //   //     if (!bloc.closeOrdersOnly)
          //   //       StreamBuilder(
          //   //           stream: bloc.orderState.stream,
          //   //           builder: (context, snapshot) {
          //   //             bool disabled = false;
          //   //             if (bloc.orderState.value is OrderIsHidden) {
          //   //               disabled = true;
          //   //             }
          //   //             return ActionButton(
          //   //               "New Order".tr(),
          //   //               disabled: disabled,
          //   //               onTap: () {
          //   //                 bloc.newOrder();
          //   //               },
          //   //             );
          //   //           }),
          //   //     SizedBox(
          //   //       width: 20.w,
          //   //     ),
          //   //     if (!bloc.closeOrdersOnly)
          //   //       StreamBuilder<Object>(
          //   //         stream: bloc.multiSelection.stream,
          //   //         builder: (context, snapshot) {
          //   //           return ActionButton(
          //   //             "Multi Selection".tr(),
          //   //             selected: bloc.multiSelection.value,
          //   //             onTap: () {
          //   //               bloc.multiSelectionMode();
          //   //             },
          //   //           );
          //   //         },
          //   //       ),
          //   //     StreamBuilder<Object>(
          //   //         stream: bloc.selectedService.stream,
          //   //         builder: (context, snapshot) {
          //   //           return Expanded(
          //   //               child: Row(
          //   //             mainAxisAlignment: MainAxisAlignment.end,
          //   //             children: [
          //   //               if (bloc.selectedService.value.type == "Delivery")
          //   //                 ActionButton(
          //   //                   "Driver Arrival".tr(),
          //   //                   onTap: () {
          //   //                     bloc.driverArrival();
          //   //                   },
          //   //                 ),
          //   //               if (bloc.selectedService.value.type == "Delivery")
          //   //                 SizedBox(
          //   //                   width: 20.w,
          //   //                 ),
          //   //               if (bloc.selectedService.value.type == "Delivery")
          //   //                 ActionButton(
          //   //                   "Driver Report".tr(),
          //   //                   onTap: () {
          //   //                     bloc.driverReport();
          //   //                   },
          //   //                 ),
          //   //               if (bloc.selectedService.value.type == "Delivery")
          //   //                 SizedBox(
          //   //                   width: 20.w,
          //   //                 ),
          //   //               ActionButton(
          //   //                 "Back".tr(),
          //   //                 icon: InvoIcons.right_arrow_next,
          //   //                 onTap: () {
          //   //                   bloc.goBack();
          //   //                 },
          //   //               )
          //   //             ],
          //   //           ));
          //   //         })
          //   //   ],
          //   // ),
          // )
        ],
      ),
    );
  }
}
