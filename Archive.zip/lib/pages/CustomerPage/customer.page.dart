import 'dart:async';
import 'dart:io';

import 'package:container_tab_indicator/container_tab_indicator.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:invo_5_widget/invo_5_widget.dart';
import 'package:invo_models/invo_models.dart';
import 'package:newcall_center/blocs/customer.page.bloc.dart';
import 'package:newcall_center/blocs/orderPage/order.page.bloc.dart';
import 'package:newcall_center/pages/OrderPage/order.page.dart';
import 'package:resize/resize.dart';

class CustomerPage extends StatefulWidget {
  final CustomerPageBloc bloc;
  const CustomerPage({super.key, required this.bloc});

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> with TickerProviderStateMixin {
  late TabController _tabController;
  String? photo;

  bool editMode = false;
  final _customerFormKey = GlobalKey<FormState>();
  final _addressFormKey = GlobalKey<FormState>();

  late CustomerPageBloc bloc;
  int tabLength = 3;

  int _selectedBranchIndex = -1;

  @override
  void initState() {
    super.initState();
    bloc = widget.bloc;

    // bloc.onCustomerChange.stream.listen((event) {
    //   setState(() {});
    // });

    // if (widget.bloc.selectMode) {
    //   tabLength = 1;
    //   if (widget.bloc.showPurchaseHistory) {
    //     tabLength = 2;
    //   }
    // }
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  dispose() {
    super.dispose();
    _tabController.dispose();
    // bloc.dispose();
  }

  pickPhoto() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );

    if (result != null) {
      setState(() {
        photo = result.files.single.path!;
      });
    } else {
      // User canceled the picker
    }
  }

  void enterEdit() async {
    await _controller.forward();
    // await _controller.reserve();
  }

  void exitEdit() async {
    await _controller.reverse();
  }

  late final AnimationController _controller = AnimationController(
    duration: const Duration(milliseconds: 200),
    vsync: this,
  );
  late final Animation<Offset> _offsetAnimation = Tween<Offset>(
    begin: const Offset(-1, 0.0),
    end: Offset.zero,
  ).animate(CurvedAnimation(
    parent: _controller,
    curve: Curves.easeIn,
  ));

  // List<Widget> addressFormat() {
  //   List<Widget> widgets = [];
  //   for (var element in bloc.addressFormats) {
  //     widgets.add(
  //       ExcludeFocus(
  //         child: Container(
  //           padding: EdgeInsets.only(top: 8.h),
  //           child: Text(
  //             element.title.tr(),
  //             textAlign: TextAlign.start,
  //             style: TextStyle(fontSize: 16.sp, height: 1.5),
  //           ),
  //         ),
  //       ),
  //     );

  //     // widgets.add(DropdownTextField(
  //     //   placeHolder: element.title.tr(),
  //     //   options: bloc.getAddressesList(element.key, addressMap),
  //     //   onSelect: (String? value) {
  //     //     bloc.setAddress(addressMap, element.key.toLowerCase(), value ?? "");
  //     //     // addressMap[element.key.toLowerCase()] = value ?? "";
  //     //     setState(() {});
  //     //   },
  //     //   initValue: addressMap[element.key.toLowerCase()] ?? "",
  //     // ));
  //     widgets.add(TypeAheadFormField(
  //       suggestionsCallback: (pattern) {
  //         return bloc.getAddressesList(element.key, addressMap);
  //       },
  //       itemBuilder: (context, String suggestion) {
  //         return ListTile(
  //           title: Text(suggestion),
  //         );
  //       },
  //       onSuggestionSelected: (String suggestion) {
  //         addressMap[element.key.toLowerCase()] = suggestion;
  //         bloc.selectedAddress.sink(bloc.selectedAddress.value);
  //       },
  //       initialValue: addressMap[element.key.toLowerCase()] ?? "",
  //     ));

  //     // widgets.add(AutoCompleteField<String>(
  //     //   optionsBuilder: (textEditingValue) {
  //     //     print(addressMap);
  //     //     return bloc.getAddressesList(element.key, addressMap);
  //     //   },
  //     //   initValue: addressMap[element.key.toLowerCase()] ?? "",
  //     //   onSelected: (String value) {
  //     //     bloc.setAddress(addressMap, element.key.toLowerCase(), value ?? "");
  //     //     // setState(() {});
  //     //   },
  //     //   optionsViewBuilder:
  //     //       (BuildContext context, AutocompleteOnSelected<String> onSelected, Iterable<String> options) {
  //     //     return Align(
  //     //       alignment: Alignment.topLeft,
  //     //       child: Material(
  //     //         color: Colors.white,
  //     //         child: Container(
  //     //           clipBehavior: Clip.antiAlias,
  //     //           width: 350.w,
  //     //           height: 150.h,
  //     //           decoration: BoxDecoration(
  //     //             color: Colors.white.withOpacity(0.6),
  //     //             // border: Border.all(
  //     //             //   width: 2,
  //     //             //   color: Color.fromRGBO(190, 190, 190, 1),
  //     //             // ),
  //     //             borderRadius: BorderRadius.circular(10.r),
  //     //           ),
  //     //           child: ListView.builder(
  //     //             padding: EdgeInsets.all(10.w),
  //     //             itemCount: options.length,
  //     //             itemBuilder: (BuildContext context, int index) {
  //     //               final String option = options.elementAt(index);
  //     //               return GestureDetector(
  //     //                   onTap: () {
  //     //                     onSelected(option);
  //     //                   },
  //     //                   child: Text(option,
  //     //                       style: TextStyle(color: Colors.black, fontSize: 18.sp, overflow: TextOverflow.ellipsis)));
  //     //             },
  //     //           ),
  //     //         ),
  //     //       ),
  //     //     );
  //     //   },
  //     // ));

  //     // widgets.add(
  //     //   CustomTextField(
  //     //     hint: element.title.tr(),
  //     //     validator: (v) {
  //     //       String? value = addressMap[element.key.toLowerCase()];
  //     //       if (element.isRequired) {
  //     //         if (value == null || value == "") return element.title.tr() + " Required".tr();
  //     //       } else {
  //     //         return null;
  //     //       }
  //     //     },
  //     //     callback: (txt) {
  //     //       addressMap[element.key.toLowerCase()] = txt;
  //     //     },
  //     //     initValue: addressMap[element.key.toLowerCase()] ?? "",
  //     //   ),
  //     // );
  //   }

  //   return widgets;
  // }

  @override
  Widget build(BuildContext context) {
    return KeyboardDismissOnTap(
      child: Material(
        child: Container(
          decoration: const BoxDecoration(color: Colors.white),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            (tabLength > 1)
                ? Container(
                    padding: EdgeInsets.symmetric(vertical: 25.h, horizontal: 25.w),
                    margin: const EdgeInsets.only(bottom: 0),
                    child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      onTap: (value) {
                        if (value == 1) {
                          //Purchace History
                          bloc.loadPurchaseHistory();
                        }
                      },
                      indicatorSize: TabBarIndicatorSize.label,
                      tabs: [
                        TabElement("General".tr(), 0),
                        TabElement("Purchase History".tr(), 0),
                      ],
                      unselectedLabelStyle: TextStyle(fontSize: 25.sp, color: Colors.black, fontFamily: 'Cairo'),
                      labelStyle: TextStyle(fontSize: 25.sp, fontFamily: 'Cairo', color: Colors.black, fontWeight: FontWeight.bold),
                      labelColor: Colors.black,
                      unselectedLabelColor: Colors.white,
                      indicator: ContainerTabIndicator(
                        // widthFraction: 1.0,
                        height: 1.h,
                        color: WidgetUtilts.currentSkin.primaryColor,
                        padding: EdgeInsets.only(top: 25.h),
                      ),
                    ))
                : Container(
                    padding: EdgeInsets.symmetric(vertical: 15.h, horizontal: 25.w),
                  ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  Row(
                    children: [
                      Stack(
                        alignment: AlignmentDirectional.topStart,
                        children: [
                          LayoutBuilder(builder: (context, constraints) {
                            return Container(
                              padding: EdgeInsets.symmetric(horizontal: 20.w),
                              decoration: BoxDecoration(color: const Color.fromRGBO(247, 247, 247, 1), borderRadius: const BorderRadiusDirectional.only(topEnd: Radius.circular(15)), border: Border.all(width: 1.w, color: const Color.fromRGBO(215, 215, 215, 1))),
                              width: 400.w,
                              height: constraints.maxHeight - (MediaQuery.of(context).viewInsets.bottom) + 80.h,
                              child: Form(
                                key: _customerFormKey,
                                child: ListView(
                                  children: [
                                    ExcludeFocus(
                                      child: Container(
                                        clipBehavior: Clip.antiAlias,
                                        margin: EdgeInsets.only(top: 30.h, bottom: 5.h),
                                        width: 140.w,
                                        height: 140.w,
                                        decoration: const BoxDecoration(color: Color.fromRGBO(146, 146, 146, 1), shape: BoxShape.circle),
                                        child: photo == null
                                            ? Icon(
                                                Icons.person,
                                                size: 120.sp,
                                                color: Colors.white,
                                              )
                                            : Image(
                                                width: 140,
                                                height: 140,
                                                image: FileImage(File(photo!)),
                                              ),
                                      ),
                                    ),
                                    ExcludeFocus(
                                      child: TextButton(
                                        onPressed: () {
                                          pickPhoto();
                                        },
                                        child: Text(
                                          "Add Photo".tr(),
                                          style: TextStyle(fontSize: 20.sp),
                                        ),
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        ExcludeFocus(
                                          child: Container(
                                            padding: EdgeInsets.only(top: 8.h),
                                            child: Text(
                                              "Salute".tr(),
                                              textAlign: TextAlign.start,
                                              style: TextStyle(fontSize: 16.sp, height: 1.5),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: double.infinity,
                                          height: 55.h,
                                          child: DropDownMenu<String>(
                                            hint: "Salute".tr(),
                                            selectedValue: bloc.customer.saluation,
                                            iconColor: const Color.fromRGBO(146, 146, 146, 1),
                                            color: const Color.fromRGBO(255, 255, 255, 1),
                                            borderColor: const Color.fromRGBO(215, 215, 215, 1),
                                            onChanged: (String? value) {
                                              if (value != null) {
                                                bloc.customer.saluation = value;
                                              }
                                            },
                                            [
                                              "",
                                              "Mr.".tr(),
                                              "Ms.".tr(),
                                              "Mrs.".tr(),
                                              "Dr.".tr()
                                            ].map<DropdownMenuItem<String>>((String value) {
                                              return DropdownMenuItem<String>(
                                                value: value,
                                                child: Text(
                                                  value,
                                                  style: TextStyle(fontFamily: 'Cairo', fontSize: 20.sp, color: const Color.fromRGBO(0, 0, 0, 1), height: 1.5),
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(top: 8.h),
                                          child: Text(
                                            "Name".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomTextField(
                                          hint: 'Name'.tr(),
                                          validator: (value) {
                                            if (bloc.customer.name.isEmpty) {
                                              return 'Please enter customer name'.tr();
                                            }
                                            return null;
                                          },
                                          initValue: bloc.customer.name,
                                          callback: (String txt) {
                                            bloc.customer.name = txt;
                                          },
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(top: 8.h),
                                          child: Text(
                                            "Phone No.".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomTextField(
                                          hint: 'Phone No.'.tr(),
                                          initValue: bloc.customer.phone,
                                          validator: (value) {
                                            return bloc.validatePhoneNumber();
                                          },
                                          callback: (String txt) {
                                            // if (txt == 0) {
                                            //   bloc.customer.phone = "";
                                            //   return;
                                            // }
                                            bloc.customer.phone = txt.toString();
                                          },
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 8.0),
                                          child: Text(
                                            "Mobile No.".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomDigitsField(
                                          hint: 'Mobile No.'.tr(),
                                          initValue: bloc.customer.mobile,
                                          callback: (double txt) {
                                            bloc.customer.mobile = txt.toInt().toString();
                                          },
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(top: 8.h),
                                          child: Text(
                                            "Email Address".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomTextField(
                                          hint: 'Email Address'.tr(),
                                          initValue: bloc.customer.email,
                                          callback: (String txt) {
                                            bloc.customer.email = txt.toString();
                                          },
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(top: 8.h),
                                          child: Text(
                                            "Birthday".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomDateField(
                                          hint: 'Birthday'.tr(),
                                          initValue: bloc.customer.birthDay,
                                          callback: (value) {
                                            bloc.customer.birthDay = value;
                                          },
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(top: 8.h),
                                          child: Text(
                                            "CardNo MSR".tr(),
                                            textAlign: TextAlign.start,
                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                          ),
                                        ),
                                        CustomTextField(
                                          hint: 'CardNo MSR'.tr(),
                                          initValue: bloc.customer.MSR,
                                          callback: (String txt) {
                                            bloc.customer.MSR = txt;
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                          SlideTransition(
                            position: _offsetAnimation,
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: LayoutBuilder(builder: (context, constraints) {
                                return Container(
                                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                                  decoration: BoxDecoration(color: const Color.fromRGBO(247, 247, 247, 1), borderRadius: const BorderRadius.only(topRight: Radius.circular(15)), border: Border.all(width: 1.w, color: const Color.fromRGBO(215, 215, 215, 1))),
                                  width: 400.w,
                                  height: constraints.maxHeight - (MediaQuery.of(context).viewInsets.bottom) + 80.h,
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                                    Container(
                                      margin: EdgeInsets.only(top: 20.h, bottom: 10.h),
                                      child: Text(
                                        "Address Info".tr(),
                                        textAlign: TextAlign.start,
                                        style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    Expanded(
                                      child: StreamBuilder(
                                          stream: bloc.selectedAddress.stream,
                                          builder: (context, snapshot) {
                                            if (bloc.selectedAddress.value == null) {
                                              return const SizedBox();
                                            }
                                            return Form(
                                                key: _addressFormKey,
                                                child: SingleChildScrollView(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      ExcludeFocus(
                                                        child: Container(
                                                          padding: EdgeInsets.only(top: 8.h),
                                                          child: Text(
                                                            "Address Title".tr(),
                                                            textAlign: TextAlign.start,
                                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                                          ),
                                                        ),
                                                      ),
                                                      CustomTextField(
                                                        hint: 'Address Title'.tr(),
                                                        validator: (value) {
                                                          if (bloc.selectedAddress.value!.title == "") {
                                                            return 'Address Title'.tr() + " Required".tr();
                                                          }
                                                          return null;
                                                        },
                                                        callback: (txt) {
                                                          bloc.selectedAddress.value!.title = txt;
                                                        },
                                                        initValue: bloc.selectedAddress.value!.title,
                                                      ),
                                                      AddressForm(bloc: bloc),
                                                      ExcludeFocus(
                                                        child: Container(
                                                          padding: EdgeInsets.only(top: 8.h),
                                                          child: Text(
                                                            "Note".tr(),
                                                            textAlign: TextAlign.start,
                                                            style: TextStyle(fontSize: 16.sp, height: 1.5),
                                                          ),
                                                        ),
                                                      ),
                                                      CustomTextArea(
                                                        key: GlobalKey(),
                                                        hint: 'Note'.tr(),
                                                        initValue: bloc.selectedAddress.value!.note,
                                                      ),
                                                    ],
                                                  ),
                                                ));
                                          }),
                                    ),
                                    KeyboardVisibilityBuilder(builder: (context, isKeyboardVisible) {
                                      if (isKeyboardVisible) {
                                        return Container();
                                      } else {
                                        return Container(
                                          height: 50.h,
                                          margin: EdgeInsets.only(bottom: 20.h),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: OptionButton(
                                                  "Cancel".tr(),
                                                  fontSize: 20.sp,
                                                  style: "info",
                                                  padding: EdgeInsets.symmetric(vertical: 7.h, horizontal: 10.w),
                                                  onTap: () => exitEdit(),
                                                ),
                                              ),
                                              SizedBox(width: 10.w),
                                              Expanded(
                                                child: OptionButton(
                                                  "Save".tr(),
                                                  fontSize: 20.0.sp,
                                                  style: "info",
                                                  padding: EdgeInsets.symmetric(vertical: 7.h, horizontal: 10.w),
                                                  onTap: () {
                                                    if (_addressFormKey.currentState!.validate()) {
                                                      bloc.selectedAddress.value!.copyAddressFormat(bloc.addressMap);
                                                      bloc.saveAddress();
                                                      exitEdit();
                                                    }
                                                  },
                                                ),
                                              )
                                            ],
                                          ),
                                        );
                                      }
                                    }),
                                  ]),
                                );
                              }),
                            ),
                          )
                        ],
                      ),
                      ExcludeFocus(
                        child: Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 450.h,
                                padding: EdgeInsets.symmetric(horizontal: 40.w),
                                child: StreamBuilder(
                                  stream: bloc.service.stream,
                                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                                    return bloc.service.value.type == "PickUp"
                                        ? Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Padding(
                                                padding: EdgeInsets.symmetric(vertical: 9.0),
                                                child: Text(
                                                  "Branches",
                                                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                              Expanded(
                                                child: SizedBox(
                                                  height: 280,
                                                  width: 520,
                                                  child: StreamBuilder(
                                                    stream: bloc.branches.stream,
                                                    initialData: const [],
                                                    builder: (context, snapshot) {
                                                      return GridView.builder(
                                                          itemCount: bloc.branches.value.length,
                                                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                                            crossAxisCount: 2,
                                                            mainAxisSpacing: 5,
                                                            crossAxisSpacing: 5,
                                                            childAspectRatio: 4,
                                                          ),
                                                          itemBuilder: (context, index) {
                                                            return Material(
                                                              child: InkWell(
                                                                splashColor: Colors.grey,
                                                                borderRadius: const BorderRadius.all(Radius.circular(9)),
                                                                onTap: () {
                                                                  setState(() {
                                                                    if (_customerFormKey.currentState!.validate()) {
                                                                      bloc.selectBranch(bloc.branches.value[index]);
                                                                      // Navigator.of(context).push(
                                                                      //   MaterialPageRoute<void>(
                                                                      //     builder: (BuildContext context) => OrderPage(
                                                                      //       bloc: OrderPageBloc(Service(id: "", name: "PickUp", type: "PickUp", index: _selectedBranchIndex)),
                                                                      //     ),
                                                                      //   ),
                                                                      // );
                                                                    }
                                                                  });
                                                                },
                                                                child: Ink(
                                                                  decoration: BoxDecoration(
                                                                      border: Border.all(
                                                                        color: Colors.black45,
                                                                      ),
                                                                      color: Colors.grey[200],
                                                                      // color: isTapped ? Color.fromARGB(255, 149, 212, 241) : Color.fromARGB(255, 194, 226, 248),
                                                                      borderRadius: const BorderRadius.all(Radius.circular(9))),
                                                                  child: Padding(
                                                                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
                                                                      child: Center(
                                                                          child: Text(
                                                                        bloc.branches.value[index].name,
                                                                        style: const TextStyle(fontSize: 18),
                                                                      ))),
                                                                ),
                                                              ),
                                                            );
                                                          });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )
                                        : Column(
                                            children: [
                                              Container(
                                                margin: EdgeInsets.only(bottom: 20.h),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 240.w,
                                                      height: 40.h,
                                                      child: OptionButton(
                                                        "Add Address".tr(),
                                                        textAlign: TextAlign.left,
                                                        fontSize: 20.0.sp,
                                                        lineHeight: 1.5,
                                                        icon: Icons.add,
                                                        iconSize: 30.0.sp,
                                                        onTap: () {
                                                          enterEdit();
                                                          // bloc.addAddress();
                                                        },
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: StreamBuilder(
                                                    stream: bloc.addressesUpdated.stream,
                                                    builder: (context, snapshot) {
                                                      return AddressesWidget(bloc.customer.addresses, (address) {
                                                        enterEdit();
                                                        bloc.editAddress(address);
                                                      }, (address) {
                                                        exitEdit();
                                                        bloc.deleteAddress(address);
                                                      });
                                                    }),
                                              ),
                                            ],
                                          );
                                  },
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                                  decoration: BoxDecoration(color: WidgetUtilts.currentSkin.bgColor.withOpacity(0.1), borderRadius: BorderRadius.only(topRight: Radius.circular(70.r))),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ExcludeFocus(
                                        child: Container(
                                          // width: 206.w,
                                          height: 40.h,
                                          margin: EdgeInsets.only(top: 30.h, bottom: 10.h),
                                          child: OptionButton(
                                            "Add Note".tr(),
                                            textAlign: TextAlign.left,
                                            fontSize: 20.0.sp,
                                            lineHeight: 1.5,
                                            icon: Icons.add,
                                            iconSize: 30.0.sp,
                                            style: "custom",
                                            customColors: [
                                              Colors.transparent,
                                              const LinearGradient(
                                                colors: [
                                                  Colors.transparent,
                                                  Colors.transparent,
                                                ],
                                                begin: Alignment.topCenter,
                                                end: Alignment.bottomCenter,
                                              ),
                                              WidgetUtilts.currentSkin.primaryColor,
                                              Colors.transparent,
                                              Colors.transparent
                                            ],
                                            onTap: () => bloc.addNote(),
                                          ),
                                        ),
                                      ),
                                      // Container(
                                      //   width: double.infinity,
                                      //   margin: EdgeInsets.only(bottom: 20.h),
                                      //   height:
                                      //       (MediaQuery.of(context).size.height -
                                      //               385.h) /
                                      //           2,
                                      //   child: StreamBuilder(
                                      //       stream: bloc.notesUpdated.stream,
                                      //       builder: (context, snapshot) {
                                      //         return Attentions(
                                      //           key: GlobalKey(),
                                      //           notes: bloc.customer.notes,
                                      //           onDelete: (note) {
                                      //             bloc.deleteNote(note);
                                      //           },
                                      //           onEdit: (note) {
                                      //             bloc.editNote(note);
                                      //           },
                                      //         );
                                      //       }),
                                      // )
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                  PurchaseHistory(
                    bloc: bloc,
                  ),
                ],
              ),
            ),
            Container(
              height: 80.h,
              padding: EdgeInsets.symmetric(horizontal: 30.w),
              decoration: BoxDecoration(
                gradient: WidgetUtilts.currentSkin.actionBar,
              ),
              child: Row(
                children: <Widget>[
                  ActionButton("Change Customer".tr(), onTap: () {
                    // bloc.changeCustomer();
                  }),
                  SizedBox(
                    width: 20.w,
                  ),
                  StreamBuilder(
                    stream: bloc.service.stream,
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      return bloc.service.value.type == "PickUp"
                          ? ActionButton("Delivery".tr(), onTap: () {
                              bloc.changeService(bloc.service.value);
                              openDialog(context);
                            })
                          : ActionButton("PickUp".tr(), onTap: () {
                              bloc.changeService(bloc.service.value);
                              openDialog(context);
                            });
                    },
                  ),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ActionButton(
                        "Back".tr(),
                        icon: InvoIcons.right_arrow_next,
                        onTap: () {
                          Navigator.pop(context);
                          // bloc.cancel();
                        },
                      )
                    ],
                  ))
                ],
              ),
            )
          ]),
        ),
      ),
    );
  }
}

class PurchaseHistory extends StatefulWidget {
  final CustomerPageBloc bloc;
  const PurchaseHistory({Key? key, required this.bloc}) : super(key: key);

  @override
  State<PurchaseHistory> createState() => _PurchaseHistoryState();
}

class _PurchaseHistoryState extends State<PurchaseHistory> {
  String vType = "grid";
  final StreamController<String> vTypeController = StreamController<String>.broadcast();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 15.h, horizontal: 15.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
              width: 380.w,
              child: StreamBuilder(
                  stream: null,
                  builder: (context, snapshot) {
                    if (widget.bloc.order.value == null) {
                      return Container(
                        color: Colors.transparent,
                      );
                    }
                    return Ticket(
                      380.w,
                      key: GlobalKey(),
                      invoice: Invoice(),
                      selectableItems: false,
                    );
                  })),
          Container(
              width: 220.w,
              margin: EdgeInsets.symmetric(horizontal: 10.w),
              padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15.r), color: WidgetUtilts.currentSkin.bgColor),
              child: SingleChildScrollView(
                child: StreamBuilder(
                    stream: null, // widget.bloc.order.stream,
                    builder: (context, snapshot) {
                      if (widget.bloc.order.value != null) {
                        Invoice order = widget.bloc.order.value!;
                        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          SizedBox(
                            height: 60.h,
                            child: OptionButton(
                              "ReOrder".tr(),
                              fontSize: 22.sp,
                              margin: EdgeInsets.only(bottom: 10.h),
                              onTap: () {
                                widget.bloc.reOrder();
                              },
                            ),
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          if (order.isEditVisible)
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                "Edit Order".tr(),
                                fontSize: 22.sp,
                                margin: EdgeInsets.only(bottom: 10.h),
                                onTap: () {
                                  widget.bloc.editOrder();
                                },
                              ),
                            ),
                          if (order.paid())
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                "Return Order".tr(),
                                fontSize: 22.sp,
                                margin: EdgeInsets.only(bottom: 10.h),
                                onTap: () {
                                  widget.bloc.returnInvoice();
                                },
                              ),
                            ),
                          Container(
                            margin: EdgeInsets.only(bottom: 10.h),
                            height: 60.h,
                            child: OptionButton(
                              "Print Ticket".tr(),
                              fontSize: 22.sp,
                              margin: EdgeInsets.only(bottom: 10.h),
                            ),
                          ),

                          if (order.isVoidVisible)
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                "Void Ticket".tr(),
                                fontSize: 22.sp,
                                onTap: () {
                                  widget.bloc.voidTicket();
                                },
                                margin: EdgeInsets.only(bottom: 10.h),
                              ),
                            ),
                          if (order.isFollowUpVisible)
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                "Follow Up".tr(),
                                fontSize: 22.sp,
                                margin: EdgeInsets.only(bottom: 10.h),
                              ),
                            ),
                          if (order.isSurchargeVisible)
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                order.chargeAmount > 0 ? "Remove Surcharge".tr() : "Surcharge".tr(),
                                onTap: () {
                                  widget.bloc.showSurchargeOrder();
                                },
                                fontSize: 22.sp,
                                margin: EdgeInsets.only(bottom: 10.h),
                              ),
                            ),
                          if (order.isDiscountVisible)
                            Container(
                              margin: EdgeInsets.only(bottom: 10.h),
                              height: 60.h,
                              child: OptionButton(
                                order.discountAmount > 0 ? "Remove Discount".tr() : "Discount".tr(),
                                onTap: () {
                                  widget.bloc.showDiscountOrder();
                                },
                                fontSize: 22.sp,
                                margin: EdgeInsets.only(bottom: 10.h),
                              ),
                            ),
                          // SizedBox(
                          //   height: 60.h,
                          //   child: OptionButton(
                          //     fontSize: 22.sp,
                          //     "Send Email".tr(),
                          //     margin: EdgeInsets.only(bottom: 10.h),
                          //   ),
                          // ),
                        ]);
                      }
                      return const SizedBox();
                    }),
              )),
          Expanded(
              child: Container(
            margin: EdgeInsets.symmetric(horizontal: 20.w),
            child: Column(
              children: [
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Order List".tr(),
                          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, height: 1),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            padding: const EdgeInsets.all(0),
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.r),
                            ),
                          ),
                          child: StreamBuilder(
                              stream: vTypeController.stream,
                              builder: (context, snapshot) {
                                return Ink(
                                    height: 45.h,
                                    width: 45.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10.r),
                                      color: WidgetUtilts.currentSkin.lightButton,
                                    ),
                                    child: Icon(
                                      vType == "list" ? Icons.grid_view : Icons.list,
                                      size: 25.sp,
                                      color: WidgetUtilts.currentSkin.lightButtonText,
                                    ));
                              }),
                          onPressed: () async {
                            if (vType == "list") {
                              vType = "grid";
                              vTypeController.sink.add("grid");
                            } else {
                              vType = "list";
                              vTypeController.sink.add("list");
                            }
                          },
                        )
                      ],
                    ),
                    SizedBox(
                      height: 20.h,
                    ),
                    Expanded(
                      child: StreamBuilder(
                        stream: widget.bloc.orders.stream,
                        builder: (context, snapshot) {
                          return StreamBuilder(
                              stream: vTypeController.stream,
                              builder: (context, snapshot) {
                                if (vType == "grid") {
                                  return GridViewOrders(
                                      orders: const [],
                                      onTab: (order) {
                                        widget.bloc.selectInvoice(order);
                                      });
                                } else {
                                  return ListViewOrders(
                                      orders: const [],
                                      onTab: (order) {
                                        widget.bloc.selectInvoice(order);
                                      });
                                }
                              });
                        },
                      ),
                    ),
                    SizedBox(
                      height: 20.h,
                    ),
                  ],
                )),
                Container(
                  height: 50.h,
                  padding: EdgeInsets.symmetric(horizontal: 10.w),
                  decoration: BoxDecoration(borderRadius: const BorderRadius.all(Radius.circular(10)), color: const Color.fromRGBO(247, 247, 247, 1), border: Border.all(width: 1.w, color: const Color.fromRGBO(215, 215, 215, 1))),
                  child: StreamBuilder(
                      stream: null, //widget.bloc.orders.stream,
                      builder: (context, snapshot) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "${"Total Sale".tr()}:",
                                  style: const TextStyle(fontSize: 20),
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Text(
                                  widget.bloc.totalSale.toCurrency(),
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Text(
                                  "${"Total Order".tr()}:",
                                  style: const TextStyle(fontSize: 20),
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Text(
                                  widget.bloc.totalOrder.toString(),
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Text(
                                  "${"Avg Order".tr()}:",
                                  style: const TextStyle(fontSize: 20),
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Text(
                                  widget.bloc.avgOrder.toCurrency(),
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ],
                        );
                      }),
                )
              ],
            ),
          ))
        ],
      ),
    );
  }
}

class AddressForm extends StatefulWidget {
  final CustomerPageBloc bloc;

  const AddressForm({Key? key, required this.bloc}) : super(key: key);

  @override
  State<AddressForm> createState() => _AddressFormState();
}

class _AddressFormState extends State<AddressForm> {
  Map<String, TextEditingController> textEditControllers = {};
  List<Widget> addressFormat() {
    List<Widget> widgets = [];
    for (var element in widget.bloc.addressFormats) {
      TextEditingController textEditingController = TextEditingController();
      textEditControllers[element.key] = textEditingController;
      widgets.add(
        ExcludeFocus(
          child: Container(
            padding: EdgeInsets.only(top: 8.h),
            child: Text(
              element.title.tr(),
              textAlign: TextAlign.start,
              style: TextStyle(fontSize: 16.sp, height: 1.5),
            ),
          ),
        ),
      );

      widgets.add(AutoCompleteField<String>(
        //key: GlobalKey(),
        optionsBuilder: (textEditingValue) {
          List<String> list = widget.bloc.getAddressesList(element.key, widget.bloc.addressMap);
          return textEditingValue.text.isEmpty ? list : list.where((f) => f == textEditingValue.text);
        },
        initValue: widget.bloc.addressMap[element.key.toLowerCase()] ?? "",
        clearBtn: true,
        onClear: () {
          widget.bloc.setAddress(widget.bloc.addressMap, element.key.toLowerCase(), "");
          setState(() {});
        },
        onSelected: (String value) {
          widget.bloc.setAddress(widget.bloc.addressMap, element.key.toLowerCase(), value);
          setState(() {});
        },
        onTextChange: (String value) {
          widget.bloc.setAddress(widget.bloc.addressMap, element.key.toLowerCase(), value);
          //don't update view on text change (no setstate)
        },
        validator: (v) {
          String? value = widget.bloc.addressMap[element.key.toLowerCase()];
          if (element.isRequired) {
            if (value == null || value == "") {
              return element.title.tr() + " Required".tr();
            }
          } else {
            return null;
          }
          return null;
        },
        optionsViewBuilder: (BuildContext context, AutocompleteOnSelected<String> onSelected, Iterable<String> options) {
          return Align(
            alignment: Alignment.topLeft,
            child: Material(
              color: Colors.white,
              child: Container(
                clipBehavior: Clip.antiAlias,
                width: 350.w,
                height: 150.h,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.6),
                  // border: Border.all(
                  //   width: 2,
                  //   color: Color.fromRGBO(190, 190, 190, 1),
                  // ),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: ListView.builder(
                  padding: EdgeInsets.all(10.w),
                  itemCount: options.length,
                  itemBuilder: (BuildContext context, int index) {
                    final String option = options.elementAt(index);
                    return GestureDetector(
                        onTap: () {
                          onSelected(option);
                        },
                        child: Text(option, style: TextStyle(color: Colors.black, fontSize: 18.sp, overflow: TextOverflow.ellipsis)));
                  },
                ),
              ),
            ),
          );
        },
      ));

      // widgets.add(
      //   CustomTextField(
      //     hint: element.title.tr(),
      //     validator: (v) {
      //       String? value = widget.bloc.addressMap[element.key.toLowerCase()];
      //       if (element.isRequired) {
      //         if (value == null || value == "") return element.title.tr() + " Required".tr();
      //       } else {
      //         return null;
      //       }
      //     },
      //     callback: (txt) {
      //       widget.bloc.addressMap[element.key.toLowerCase()] = txt;
      //     },
      //     initValue: widget.bloc.addressMap[element.key.toLowerCase()] ?? "",
      //   ),
      // );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ...addressFormat()
      ],
    );
  }
}
/////////?????????????????????????????

Future openDialog(context) => showMenu(
        context: context,
        constraints: const BoxConstraints(
          maxWidth: double.infinity,
          maxHeight: double.infinity,
        ),
        position: const RelativeRect.fromLTRB(180, 538, 180, 0),
        items: [
          const PopupMenuItem(enabled: false, child: Center(child: ChangeService()))
        ]);

List<String> servicesList = [
  'Pick UP',
  'Car Hop',
  'Delivery',
  'Carriage',
];

class ChangeService extends StatefulWidget {
  const ChangeService({super.key});
  Color getTextColor(bool isHovered) {
    return isHovered ? Colors.white : Colors.black;
  }

  Color getContainerColor(bool isHovered) {
    return isHovered ? Colors.blue : Colors.black12;
  }

  @override
  State<ChangeService> createState() => _ChangeServiceState();
}

class _ChangeServiceState extends State<ChangeService> {
  int? selectedserver;
  late CustomerPageBloc bloc;
  List<bool> isHovered = List.filled(servicesList.length, false);
  void _updateColor(int index, bool hovered) {
    setState(() {
      (selectedserver == index) ? false : isHovered[index] = hovered;
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Object>(
        stream: null, //bloc.service.stream,
        builder: (context, snapshot) {
          return Container(
            height: 115,
            width: (servicesList.length > 4) ? (14 + (servicesList.length * 100)) : 414,
            child: Center(
              child: GridView.builder(
                itemCount: servicesList.length, //bloc.services.length, // servicesList.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: servicesList.length,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 9,
                ),
                itemBuilder: (context, index) => MouseRegion(
                  onHover: (event) => _updateColor(index, true),
                  onExit: (event) => _updateColor(index, false),
                  child: GestureDetector(
                    onTap: () {
                      selectedserver = index;
                      setState(() {
                        _updateColor(index, true);
                      });
                      bloc.changeService(bloc.service.value);
                      print("selectedserver" + ' $index');
                    },
                    child: Container(
                      color: const ChangeService().getContainerColor(isHovered[index]),
                      child: Center(
                        child: Text(
                          // bloc.service.value.type,
                          // bloc.services.[index],
                          servicesList[index],
                          style: TextStyle(
                            fontSize: 16,
                            color: const ChangeService().getTextColor(isHovered[index]),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }
}
