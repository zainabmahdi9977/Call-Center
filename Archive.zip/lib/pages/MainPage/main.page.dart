import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:invo_5_widget/invo_5_widget.dart';
import 'package:newcall_center/blocs/main.bloc.dart';
import 'package:newcall_center/pages/HomePage/home.page.dart';
import 'package:newcall_center/utils/dialog.service.dart';
import 'package:newcall_center/utils/naviagtion.service.dart';
import 'package:resize/resize.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late MainBloc bloc;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    bloc = MainBloc();
    loading();
  }

  bool loadingComplete = false;
  loading() async {
    await bloc.loadData();
    setState(() {
      loadingComplete = true;
    });
  }

  double headerHeight = 70.h;
  @override
  Widget build(BuildContext context) {
    if (!GetIt.instance.isRegistered<NavigationService>()) {
      GetIt.instance.registerSingleton<NavigationService>(NavigationService(context));
    } else {
      GetIt.instance.get<NavigationService>().context = context;
    }

    DialogService.mainContext = context;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        bottom: false,
        child: !loadingComplete
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : SingleChildScrollView(
                physics: const NeverScrollableScrollPhysics(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  key: GlobalKey(),
                  decoration: BoxDecoration(
                    gradient: WidgetUtilts.currentSkin.bgGradient,
                    // image: DecorationImage(
                    //     alignment: Alignment.topLeft,
                    //     // image: Svg("assets/images/dot.svg",
                    //     //     color: WidgetUtilts.currentSkin.skinPattern,
                    //     //     size: Size(15.w, 15.w),
                    //     //     scale: 1),
                    //     fit: BoxFit.none,
                    //     opacity: 0.03,
                    //     repeat: ImageRepeat.repeat),
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        height: headerHeight,
                        color: Colors.blue[1200],
                        child: TopBar(),
                      ),
                      // SingleChildScrollView(
                      //     physics: const NeverScrollableScrollPhysics(),
                      //     child: SizedBox(
                      //         width: 150.w,
                      //         height: MediaQuery.of(context).size.height,
                      //         child: SideMenu())),
                      Expanded(
                        child: SingleChildScrollView(
                          physics: const NeverScrollableScrollPhysics(),
                          child: Container(
                            clipBehavior: Clip.antiAlias,
                            height: MediaQuery.of(context).size.height - headerHeight,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadiusDirectional.only(
                                topStart: Radius.circular(40.r),
                                topEnd: Radius.circular(40.r),
                              ),
                            ),
                            child: Navigator(
                              // key: Utilts.mainPageNavigationKey,

                              initialRoute: "/",
                              onGenerateRoute: (RouteSettings settings) {
                                Widget page;
                                String pageName = settings.name.toString();
                                switch (pageName) {
                                  case "Home":
                                    page = const HomePage();
                                    break;
                                  default:
                                    pageName = "";
                                    page = const HomePage();
                                }

                                if (settings.name == "/") {
                                  return PageRouteBuilder(pageBuilder: (ctx, animation, secAndimation) => page);
                                }

                                return PageRouteBuilder(
                                  pageBuilder: (ctx, animation, secAndimation) => page,
                                  transitionsBuilder: (context, animation, secondaryAnimation, child) {
                                    const begin = Offset(1, 0);
                                    const end = Offset.zero;
                                    const curve = Curves.ease;

                                    var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

                                    return SlideTransition(
                                      position: animation.drive(tween),
                                      child: child,
                                    );
                                  },
                                  transitionDuration: const Duration(milliseconds: 400),
                                );
                                return null;
                              },
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class TopBar extends StatelessWidget {
  const TopBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Spacer(),
        Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 6, right: 21.0),
          child: GestureDetector(
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(5)), border: Border.all(color: Colors.white), color: Colors.transparent),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: const Text(
                  'Ali ',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            onTap: () {
              openDialog(context);
            },
          ),
        ),
      ],
    );
  }
}

Future openDialog(context) => showMenu(
      context: context,
      position: RelativeRect.fromLTRB(280, 50, 40, 0),
      items: [
        PopupMenuItem(enabled: false, child: ShortCutPopup())
      ],
    );

List<String> ShortCut = [
  'العربية',
  'Reports',
  'Setting',
  'Log Out',
];
Color getTextColor(bool isHovered) {
  return isHovered ? Colors.white : Colors.black;
}

Color getContainerColor(bool isHovered) {
  return isHovered ? Colors.blue : Colors.black12;
}

class ShortCutPopup extends StatefulWidget {
  const ShortCutPopup({super.key});

  @override
  State<ShortCutPopup> createState() => _ShortCutPopupState();
}

class _ShortCutPopupState extends State<ShortCutPopup> {
  List<bool> isHovered = List.filled(ShortCut.length, false);
  void _updateColor(int index, bool hovered) {
    setState(() {
      isHovered[index] = hovered;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 280,
      width: 430,
      child: Center(
        child: GridView.builder(
          itemCount: ShortCut.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 9,
          ),
          itemBuilder: (context, index) => MouseRegion(
            onHover: (event) => _updateColor(index, true),
            onExit: (event) => _updateColor(index, false),
            child: GestureDetector(
              onTap: () {
                setState(() {});
              },
              child: Container(
                decoration: BoxDecoration(
                  color: getContainerColor(isHovered[index]),
                ),
                child: Center(
                  child: Text(
                    ShortCut[index],
                    style: TextStyle(
                      fontSize: 16,
                      color: getTextColor(isHovered[index]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
