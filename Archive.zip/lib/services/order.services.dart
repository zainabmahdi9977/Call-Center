import 'dart:convert';
import 'package:invo_models/invo_models.dart';
import 'package:invo_models/models/Invoice.dart';

import 'package:http/http.dart' as http;

import 'login.services.dart';
import 'varHttp.dart';

class OrderService {
  Future<Invoice> addInvoice() async {
    String token = (await LoginServices().getToken())!;
    final response = await http.post(
      Uri.parse('${myHTTP}order/SaveOrder'),
      headers: {
        "Api-Auth": token.toString()
      },
    );
    if (response.statusCode == 200) {
      return Invoice.fromJson(jsonDecode(response.body) as Map<String, dynamic>);
    } else {
      throw Exception('Failed to load Invoice');
    }
  }

  Future<Object> getCustomerInvoices(customerId) async {
    String token = (await LoginServices().getToken())!;

    final response = await http.get(
      Uri.parse('${myHTTP}order/getOrders/$customerId'),
      headers: {
        "Api-Auth": token.toString()
      },
    );
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      if (map['success']) {
        return Invoice.fromJson(map['data']);
      }
      return Invoice().customerId.toString();
    } else {
      throw Exception('Failed to load CustomerInvoices');
    }
  }

  Future<Object> getInvoiceById(invoiceId) async {
    String token = (await LoginServices().getToken())!;

    final response = await http.get(
      Uri.parse('${myHTTP}order/getOrder/$invoiceId'),
      headers: {
        "Api-Auth": token.toString()
      },
    );
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      if (map['success']) {
        return Invoice.fromJson(map['data']);
      }
      return Invoice().id.toString();
    } else {
      throw Exception('Failed to load Invoice ById');
    }
  }

  Future saveInvoice(
    Invoice invoice,
    String branchId,
  ) async {
    //String branchId
    try {
      String token = (await LoginServices().getToken())!;
      Map map = invoice.toFullMap();
      map['branchId'] = branchId;
      final response = await http.post(
        Uri.parse('${myHTTP}order/saveInvoice'),
        headers: {
          "Api-Auth": token.toString(),
          "Content-Type": "application/json"
        },
        body: jsonEncode(map),
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body);
        if (map["success"]) {}
      }

      return null;
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

// String Employee, String Branch, String Ticket
  Future<List<InvoiceMini>> getOrders(String? Employee, String? Branch, String? Filter) async {
    String token = (await LoginServices().getToken())!;
    final response = await http.post(Uri.parse('${myHTTP}order/getInvoices'), //this http only for getOrders
        headers: {
          "Api-Auth": token.toString(),
          "Content-Type": "application/json"
        },
        body: jsonEncode({
          "employeeId": Employee,
          "branchId": Branch,
          "filter": Filter
        }));
    List<InvoiceMini> orders = [];
    if (response.statusCode == 200) {
      List<dynamic> map = jsonDecode(response.body);
      for (var element in map) {
        orders.add(InvoiceMini.fromJson(element));
      }
      print(orders);
    }
    return orders;
  }

  Future<Invoice?> getInvoice(String id) async {
    String token = (await LoginServices().getToken())!;
    final response = await http.get(
      Uri.parse('${myHTTP}getOrder/$id'),
      headers: {
        "Api-Auth": token.toString(),
        "Content-Type": "application/json"
      },
    );
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      print("${Invoice.fromFullJson(map).toString()}");
      return Invoice.fromFullJson(map);
    }
    return null;
  }

  Future<Invoice?> getInvoicesByCustomerID(String customerId) async {
    String token = (await LoginServices().getToken())!;
    final response = await http.get(
      Uri.parse('${myHTTP}getInvoicesByCustomerID/$customerId'),
      headers: {
        "Api-Auth": token.toString(),
        "Content-Type": "application/json"
      },
    );
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      return Invoice.fromFullJson(map);
    }
    return null;
  }
}
