String myHTTP = "http://10.2.2.49:3001/v1/callcenter/";


// myHTTP1 = "http://10.2.2.155:3001/v1/callcenter/";
// myHTTP2 = "http://10.2.2.49:3001/v1/callcenter/";
