import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/branch.models.dart';
import 'login.services.dart';
import 'varHttp.dart';

class BranchService {
  Future<List<Branch>?> getBranchList() async {
    String token = (await LoginServices().getToken())!;
    final response = await http.get(Uri.parse('${myHTTP}company/getBranchList'), headers: {
      "Api-Auth": token.toString()
    });
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      if (map['success']) {
        List<Branch> Branches = [];
        for (var element in map['data']) {
          Branches.add(Branch.fromJson(element));
        }
        return Branches;
      }
    } else {
      throw Exception('Failed to load BranchList');
    }
    return null;
  }
}
