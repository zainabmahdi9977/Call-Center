import 'dart:convert';

import 'package:invo_models/invo_models.dart';
import 'package:invo_models/models/PriceLabel.dart';

import 'package:http/http.dart' as http;
import 'package:newcall_center/services/services.dart';

import '../models/branch.models.dart';
import 'branch.services.dart';
import 'employee.services.dart';
import 'login.services.dart';
import 'menu.services.dart';
import 'option.services.dart';
import 'order.services.dart';
import 'price.services.dart';
import 'privielg.services.dart';
import 'tex.services.dart';
import 'varHttp.dart';

class Repository {
  late String token;

  List<Service> services = [];
  List<PriceLabel> priceLabels = [];
  List<Surcharge> surcharges = [];
  List<Option> options = [];
  List<OptionGroup> optionGroups = [];

  List<Employee> employees = [];
  List<Branch> branches = [];
  List<Tax> taxes = [];
  List<Product> products = [];
  List<EmployeePrivilege> privileges = [];

  // @override
  // List<Menu> menus = [];

  // @override
  // List<MenuSection> menuSections = [];

  List<Discount> discounts = [];

  @override
  Terminal? terminal;

  @override
  Preferences? preferences;

  Repository() {
    loadToken();
  }

  loadToken() async {
    token = (await LoginServices().getToken())!;
  }

  Future<void> load() async {
    try {
      priceLabels = await Price().getPriceLabelList();
      surcharges = (await TaxService().getSurchargeList())!;
      options = (await OptionService().getOptions())!;
      optionGroups = (await OptionService().getOptionGroupList())!;
      services = await ServicesApi().getServices();
      employees = (await EmployeeService().getEmployeeList())!;
      branches = (await BranchService().getBranchList())!;
      taxes = (await TaxService().loadTax())!;
      products = (await MenuService().menuProductList());
      privileges = (await PrivielgService().getEmployeePrivielges())!;
    } catch (e) {
      print("-0-");
      print(e);
    }
  }

//////////////////////////////company

  Future<List<dynamic>?> getCompanySetting(companyId) async {
    final response = await http.get(
      Uri.parse('${myHTTP}company/getCompanySetting'),
      // headers: {"Api-Auth": accessToken},
    );
    if (response.statusCode == 200) {
      Map<String, dynamic> map = jsonDecode(response.body);
      if (map['success']) {
        List<OptionGroup> optionGroupList = [];
        for (var element in map['data']) {
          optionGroupList.add(OptionGroup.fromJson(element));
        }

        return optionGroupList;
      }
    }
    throw Exception('Failed to load CompanySetting');
  }
}
