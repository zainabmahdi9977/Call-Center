import 'package:flutter/material.dart';
import 'package:newcall_center/blocs/customer.page.bloc.dart';
import 'package:newcall_center/pages/CustomerPage/customer.page.dart';

import '../blocs/orderPage/order.page.bloc.dart';
import '../pages/LoginPage/login.page.dart';
import '../pages/MainPage/main.page.dart';
import '../pages/OrderPage/order.page.dart';

class NavigationService {
  BuildContext context;
  NavigationService(this.context);

  goToCustomerPage(CustomerPageBloc bloc) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => CustomerPage(bloc: bloc),
      ),
    );
  }

  goToOrderPage(OrderPageBloc bloc) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => OrderPage(bloc: bloc),
      ),
    );
  }

  gotoLoginPage() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const LoginPage(),
      ),
    );
  }

  gotoHomePage() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const MainPage(),
      ),
    );
  }
}
