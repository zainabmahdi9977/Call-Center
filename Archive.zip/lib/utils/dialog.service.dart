import 'dart:async';
import 'dart:io';

import 'package:data_table_2/data_table_2.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:invo_5_widget/invo_5_widget.dart';
import 'package:invo_models/invo_models.dart';
import 'package:resize/resize.dart';

class DialogService {
  static BuildContext? mainContext;
  bool isWindowsPlatform() {
    if (kIsWeb) {
      return false;
    } else {
      if (Platform.isWindows) {
        return true;
      }
    }
    return false;
  }

  @override
  Future<bool> confirmationDialog(String title, String msg) async {
    if (mainContext == null) return false;
    bool? x = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 300.h,
                width: 350.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Text(
                        msg,
                        style: TextStyle(
                          fontSize: 20.sp,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "danger",
                                  onTap: () {
                                    Navigator.of(context).pop(false);
                                  },
                                ),
                                OptionButton(
                                  "Yes".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                  onTap: () {
                                    Navigator.of(context).pop(true);
                                  },
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });
    if (x == null) {
      return false;
    }
    return x;
  }

  @override
  Future<bool?> alertDialog(String title, String msg) async {
    await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 300.h,
                width: 350.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Text(
                        msg,
                        style: TextStyle(
                          fontSize: 20.sp,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            OptionButton(
                              "OK".tr(),
                              lineHeight: 1.2,
                              padding: EdgeInsets.symmetric(
                                  vertical: 10.h, horizontal: 20.w),
                              fontSize: 20.sp,
                              style: "primary",
                              onTap: () {
                                Navigator.of(context).pop(true);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });
    return true;
  }

  @override
  Future<Discount?> discountListDialog(
      String title, List<Discount> discounts) async {
    List<Widget> discountBtns = [];
    for (var element in discounts) {
      discountBtns.add(DiscountButton(
        element.name,
        percent: (element.percentage)
            ? "${element.amount}%"
            : element.amount.toCurrency(),
        fontSize: 25.sp,
        onTap: () {
          Navigator.of(mainContext!).pop(element);
        },
      ));
    }
    Discount? resault = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 650.h,
                width: 800.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: GridView.count(
                          crossAxisSpacing: 15,
                          mainAxisSpacing: 15,
                          crossAxisCount: 3,
                          shrinkWrap: true,
                          childAspectRatio: 350.w / 180.h,
                          children: [
                            ...discountBtns,
                            DiscountButton(
                              "Custom Discount".tr(),
                              singleText: true,
                              fontSize: 25.sp,
                              borderColor: WidgetUtilts.currentSkin.bgColor,
                              onTap: () async {
                                double? price = await priceDialog(
                                    "Enter Discount Amount".tr());
                                if (price != null) {
                                  Navigator.of(mainContext!).pop(Discount(
                                      id: "",
                                      name: "",
                                      amount: price,
                                      percentage: false));
                                }
                              },
                            ),
                          ],
                        )),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                  onTap: () {
                                    Navigator.of(context).pop(null);
                                  },
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });

    return resault;
  }

  @override
  Future<Surcharge?> surchargeListDialog(List<Surcharge> surcharges) async {
    Surcharge? resault = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 650.h,
                width: 800.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Surcharge".tr(),
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: GridView.builder(
                          itemCount: surcharges.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisSpacing: 15,
                            mainAxisSpacing: 15,
                            crossAxisCount: 3,
                            childAspectRatio: 350.w / 180.h,
                          ),
                          itemBuilder: (ctx, index) {
                            return DiscountButton(
                              surcharges[index].name,
                              percent: (surcharges[index].percentage)
                                  ? "${surcharges[index].amount}%"
                                  : surcharges[index].amount.toCurrency(),
                              onTap: () {
                                Navigator.of(context).pop(surcharges[index]);
                              },
                              fontSize: 25.sp,
                            );
                          },
                          shrinkWrap: true,
                        )),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });
    return resault;
  }

  Future<List<ProductList>> showProductList1(List<ProductList> products,
      {bool multiSelection = false}) async {
    final StreamController<String> searchController =
        StreamController<String>.broadcast();

    String filterText = "";

    List<ProductList> filterdList = products.toList();
    List<DataRow> buildProductTable(List<ProductList> products) {
      List<DataRow> menulistTableRow = [];
      for (var i = 0; i < products.length; i++) {
        menulistTableRow.add(
          DataRow(
            selected: products[i].isSelected,
            onSelectChanged: (selected) {
              if (!multiSelection) {
                for (var element in products) {
                  element.isSelected = false;
                }
              }

              if (selected != null) {
                products[i].isSelected = selected;
              }
              searchController.add(filterText);
            },
            cells: <DataCell>[
              DataCell(Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    products[i].name.trim().toString(),
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        fontSize: 18.sp, color: Colors.black, height: 1),
                  ),
                  // Container(
                  //   padding: EdgeInsets.all(4.0),
                  //   margin: EdgeInsetsDirectional.only(start: 4.0),
                  //   decoration: BoxDecoration(
                  //     color:WidgetUtilts.currentSkin.primaryColor,
                  //     borderRadius: BorderRadius.circular(8),
                  //   ),
                  //   child: Text(
                  //     products[i].type.toString(),
                  //     textAlign: TextAlign.center,
                  //     style: TextStyle(fontSize: 12.sp, color: Colors.white, height: 1),
                  //   ),
                  // )
                ],
              )),
              DataCell(Text(
                products[i].available.toString(),
                style: TextStyle(fontSize: 18.sp, color: Colors.black),
              )),
              DataCell(Text(
                products[i].barcode.toString(),
                style: TextStyle(fontSize: 18.sp, color: Colors.black),
              )),
              DataCell(Row(
                children: [
                  Text(
                    products[i].price.toCurrency(),
                    style: TextStyle(fontSize: 18.sp, color: Colors.black),
                  )
                ],
              )),
              DataCell(Container(
                margin: const EdgeInsets.all(5),
                child: (products[i].available != "")
                    ? OptionButton(
                        "Check Availability".tr(),
                        onTap: () {},
                        lineHeight: 1.2,
                        fontSize: 15.sp,
                        style: "primary",
                      )
                    : const SizedBox(),
              )),
            ],
          ),
        );
      }
      return menulistTableRow;
    }

    List<DataRow> menulistTableRow = buildProductTable(filterdList);

    List<ProductList>? x = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 847.h,
                width: 1064.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Product List".tr(),
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: CustomTextField(
                        hint: 'Search ...'.tr(),
                        focus: true,
                        callback: (value) {
                          filterText = value;
                          searchController.add(value);
                        }),
                  ),
                  Expanded(
                    child: StreamBuilder<String>(
                        stream: searchController.stream,
                        builder: (context, snapshot) {
                          if (snapshot.data != null && snapshot.data != "") {
                            menulistTableRow = [];

                            filterdList = products
                                .where((element) =>
                                    (element.name.toLowerCase().contains(
                                        snapshot.data
                                            .toString()
                                            .toLowerCase())) ||
                                    (element.barcode.toLowerCase().contains(
                                        snapshot.data
                                            .toString()
                                            .toLowerCase())) ||
                                    // ignore: unrelated_type_equality_checks
                                    (element.price ==
                                        num.tryParse(snapshot.data!)
                                            ?.toDouble()))
                                .toList();
                            menulistTableRow = buildProductTable(filterdList);
                          } else {
                            menulistTableRow = buildProductTable(products);
                          }

                          return Container(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            margin: EdgeInsets.symmetric(vertical: 20.h),
                            child:
                                LayoutBuilder(builder: (context, constraints) {
                              double availableWidth = constraints.maxWidth - 49;
                              return DataTable2(
                                sortAscending: true,
                                showCheckboxColumn: false,
                                dataRowHeight: 60.h,
                                headingRowHeight: 40,
                                columnSpacing: 1,
                                columns: <DataColumn2>[
                                  DataColumn2(
                                    fixedWidth: availableWidth * 0.4,
                                    label: Text(
                                      "Product Name".tr(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          height: 1.5.h,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onSort:
                                        (int columnIndex, bool ascending) {},
                                  ),
                                  DataColumn2(
                                    fixedWidth: availableWidth * 0.1,
                                    label: Text(
                                      "Available".tr(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          height: 1.5.h,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onSort:
                                        (int columnIndex, bool ascending) {},
                                  ),
                                  DataColumn2(
                                    fixedWidth: availableWidth * 0.25,
                                    label: Text(
                                      "Barcode".tr(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          height: 1.5.h,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onSort:
                                        (int columnIndex, bool ascending) {},
                                  ),
                                  DataColumn2(
                                    fixedWidth: availableWidth * 0.1,
                                    label: Text(
                                      "Price".tr(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          height: 1.5.h,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onSort:
                                        (int columnIndex, bool ascending) {},
                                  ),
                                  DataColumn2(
                                    fixedWidth: availableWidth * 0.15,
                                    label: Text(
                                      "",
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          height: 1.5.h,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onSort:
                                        (int columnIndex, bool ascending) {},
                                  ),
                                ],
                                rows: <DataRow>[...menulistTableRow],
                              );
                            }),
                          );
                        }),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  onTap: () {
                                    List<ProductList> selected = [];
                                    Navigator.of(context).pop(selected);
                                  },
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary".tr(),
                                ),
                                OptionButton(
                                  "Pick".tr(),
                                  onTap: () {
                                    List<ProductList> selected = products
                                        .where((f) => f.isSelected)
                                        .toList();
                                    Navigator.of(context).pop(selected);
                                  },
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });

    searchController.close();

    if (x == null) return [];
    return x;
  }

  @override
  Future<List<ProductList>> showProductList(List<ProductList> products,
      {bool multiSelection = false,
      Function(ProductList)? checkAvailabilty}) async {
    final StreamController<String> searchController =
        StreamController<String>.broadcast();
    String filterText = "";

    List<ProductList> filterdList = products.toList();
    List<ProductList>? x = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 847.h,
                width: 1080.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Product List".tr(),
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: CustomTextField(
                        hint: 'Search ...'.tr(),
                        focus: true,
                        callback: (value) {
                          filterText = value;
                          searchController.add(value);
                        }),
                  ),
                  Expanded(
                    child: StreamBuilder<String>(
                        stream: searchController.stream,
                        builder: (context, snapshot) {
                          if (snapshot.data != null && snapshot.data != "") {
                            filterdList = products
                                .where((element) =>
                                    (element.name.toLowerCase().contains(
                                        snapshot.data
                                            .toString()
                                            .toLowerCase())) ||
                                    (element.barcode.toLowerCase().contains(
                                        snapshot.data
                                            .toString()
                                            .toLowerCase())) ||
                                    // ignore: unrelated_type_equality_checks
                                    (element.price ==
                                        num.tryParse(snapshot.data!)
                                            ?.toDouble()))
                                .toList();
                            // menulistTableRow = buildProductTable(filterdList);
                          } else {
                            filterdList = products;

                            // menulistTableRow = buildProductTable(products);
                          }

                          return Container(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            margin: EdgeInsets.symmetric(vertical: 20.h),
                            child:
                                LayoutBuilder(builder: (context, constraints) {
                              double availableWidth = constraints.maxWidth - 49;
                              debugPrint(availableWidth.toString());
                              return Column(
                                children: [
                                  SizedBox(
                                    height: 40,
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: availableWidth * 0.3,
                                          child: Text(
                                            "Product Name".tr(),
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                height: 1.5.h,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        SizedBox(
                                          width: availableWidth * 0.15,
                                          child: Text(
                                            "Available".tr(),
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                height: 1.5.h,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        SizedBox(
                                          width: availableWidth * 0.25,
                                          child: Text(
                                            "Barcode".tr(),
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                height: 1.5.h,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        SizedBox(
                                          width: availableWidth * 0.15,
                                          child: Text(
                                            "Price".tr(),
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                height: 1.5.h,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        SizedBox(
                                          width: availableWidth * 0.17,
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                height: 1.5.h,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Divider(
                                    height: 1,
                                  ),
                                  Expanded(
                                    child: ListView.builder(
                                      itemExtent: 60.h,
                                      itemCount: filterdList.length,
                                      itemBuilder: (context, i) {
                                        return Container(
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSide(width: 1.w),
                                            ),
                                          ),
                                          child: InkWell(
                                            onTap: () async {
                                              if (!multiSelection) {
                                                for (var element
                                                    in filterdList) {
                                                  element.isSelected = false;
                                                }
                                              }

                                              filterdList[i].isSelected =
                                                  !filterdList[i].isSelected;
                                              searchController.sink
                                                  .add(filterText);
                                            },
                                            child: Container(
                                              color: filterdList[i].isSelected
                                                  ? const Color(0xffe0fbfc)
                                                  : Colors.white,
                                              child: Row(
                                                children: [
                                                  SizedBox(
                                                    width: availableWidth * 0.3,
                                                    child: Text(
                                                      filterdList[i]
                                                          .name
                                                          .trim()
                                                          .toString(),
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: TextStyle(
                                                          fontSize: 18.sp,
                                                          color: Colors.black,
                                                          height: 1),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width:
                                                        availableWidth * 0.15,
                                                    child: Text(
                                                      filterdList[i]
                                                          .available
                                                          .toString()
                                                          .replaceAll(
                                                              RegExp(
                                                                  r'([.]*0)(?!.*\d)'),
                                                              ''),
                                                      style: TextStyle(
                                                          fontSize: 18.sp,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width:
                                                        availableWidth * 0.25,
                                                    child: Text(
                                                      filterdList[i]
                                                          .barcode
                                                          .toString(),
                                                      style: TextStyle(
                                                          fontSize: 18.sp,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width:
                                                        availableWidth * 0.15,
                                                    child: Text(
                                                      filterdList[i]
                                                          .price
                                                          .toCurrency(),
                                                      style: TextStyle(
                                                          fontSize: 18.sp,
                                                          color: Colors.black),
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        availableWidth * 0.17,
                                                    margin:
                                                        const EdgeInsets.all(5),
                                                    child: (filterdList[i]
                                                                .available !=
                                                            "")
                                                        ? OptionButton(
                                                            "Check Availability"
                                                                .tr(),
                                                            onTap: () {
                                                              if (checkAvailabilty !=
                                                                  null) {
                                                                checkAvailabilty(
                                                                    filterdList[
                                                                        i]);
                                                              }
                                                            },
                                                            lineHeight: 1.2,
                                                            fontSize: 15.sp,
                                                            style: "primary",
                                                          )
                                                        : const SizedBox(),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                ],
                              );
                            }),
                          );
                        }),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  onTap: () {
                                    List<ProductList> selected = [];
                                    Navigator.of(context).pop(selected);
                                  },
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                ),
                                OptionButton(
                                  "Pick".tr(),
                                  onTap: () {
                                    List<ProductList> selected = products
                                        .where((f) => f.isSelected)
                                        .toList();
                                    Navigator.of(context).pop(selected);
                                  },
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });

    searchController.close();

    if (x == null) return [];
    return x;
  }

  @override
  void productAvailabilty(
      ProductList product, List<ProductBranchAvailability> branches) async {
    double totalOnHand = branches
        .map((e) => e.onHand)
        .reduce((value, element) => value + element);
    await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 600.h,
                width: 600.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          product.name,
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    margin: EdgeInsets.symmetric(vertical: 20.h),
                    child: LayoutBuilder(builder: (context, constraints) {
                      double availableWidth = constraints.maxWidth - 49;
                      return Column(
                        children: [
                          SizedBox(
                            height: 40,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: availableWidth * 0.8,
                                  child: Text(
                                    "Branch".tr(),
                                    style: TextStyle(
                                        fontSize: 18.sp,
                                        height: 1.5.h,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                SizedBox(
                                  width: availableWidth * 0.2,
                                  child: Text(
                                    "Available".tr(),
                                    style: TextStyle(
                                        fontSize: 18.sp,
                                        height: 1.5.h,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Divider(
                            height: 1,
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemExtent: 60.h,
                              itemCount: branches.length,
                              itemBuilder: (context, i) {
                                return Container(
                                  color: Colors.white,
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: availableWidth * 0.8,
                                        child: Text(
                                          branches[i].branch.toString(),
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              fontSize: 18.sp,
                                              color: Colors.black,
                                              height: 1),
                                        ),
                                      ),
                                      SizedBox(
                                        width: availableWidth * 0.2,
                                        child: Text(
                                          branches[i]
                                              .onHand
                                              .toString()
                                              .replaceAll(
                                                  RegExp(r'([.]*0)(?!.*\d)'),
                                                  ''),
                                          style: TextStyle(
                                              fontSize: 18.sp,
                                              color: Colors.black),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          const Divider(
                            height: 1,
                          ),
                          Container(
                            height: 40.h,
                            color: Colors.white,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: availableWidth * 0.8,
                                  child: Text(
                                    "Total".tr(),
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        fontSize: 25.sp, color: Colors.black),
                                  ),
                                ),
                                SizedBox(
                                  width: availableWidth * 0.2,
                                  child: Text(
                                    totalOnHand.toString().replaceAll(
                                        RegExp(r'([.]*0)(?!.*\d)'), ''),
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        fontSize: 25.sp, color: Colors.black),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      );
                    }),
                  )),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Close".tr(),
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  style: "primary",
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });
  }

  @override
  Future<String?> noteDialog({String initValue = ""}) async {
    TextEditingController textEditingController = TextEditingController();
    textEditingController.text = initValue;
    FocusNode focus = FocusNode();

    String? resault = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      useRootNavigator: false,
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: widget,
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      pageBuilder: (context, a1, a2) {
        return Dialog(
          backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
          child: Container(
            height: (isWindowsPlatform()) ? 650.h : 330.h,
            width: 1000.w,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(20.r))),
            child: Column(children: [
              Container(
                padding: EdgeInsets.all(20.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Add Note".tr(),
                      style: TextStyle(
                          fontSize: 22.sp, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    children: [
                      TextFormField(
                        // focusNode: focus,
                        autofocus: true,
                        controller: textEditingController,
                        style: TextStyle(fontSize: 18.sp),
                        maxLines: 3,
                        decoration: InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          contentPadding: EdgeInsets.all(10.w),
                          focusedBorder: OutlineInputBorder(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(
                                  width: 2.w,
                                  color: WidgetUtilts
                                      .currentSkin.primaryButtonBorder)),
                          hintStyle: TextStyle(fontSize: 18.sp),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 2.w,
                                  color:
                                      const Color.fromRGBO(215, 215, 215, 1)),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10))),
                          hintText: "Enter text ...".tr(),
                        ),
                      ),
                      SizedBox(
                        height: 15.h,
                      ),
                      if (isWindowsPlatform())
                        Keyboard(
                          onChange: (txt) {
                            textEditingController.text += txt;
                            focus.requestFocus();
                          },
                          onDelete: () {
                            try {
                              textEditingController.text =
                                  textEditingController.text.substring(
                                      0, textEditingController.text.length - 1);
                              textEditingController.selection =
                                  TextSelection.fromPosition(TextPosition(
                                      offset:
                                          textEditingController.text.length));
                              focus.requestFocus();
                            } catch (e) {
                              //error
                            }
                          },
                          onMoveCursor: (val) {
                            if (val == "backCursor") {
                              TextSelection.fromPosition(TextPosition(
                                  offset:
                                      textEditingController.text.length - 1));
                            } else {
                              TextSelection.fromPosition(TextPosition(
                                  offset:
                                      textEditingController.text.length + 1));
                            }

                            focus.requestFocus();
                          },
                        )
                    ],
                  ),
                ),
              ),
              Container(
                height: 85.h,
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                decoration: const BoxDecoration(
                    color: Color.fromRGBO(238, 238, 238, 1),
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(20),
                        bottomRight: Radius.circular(20))),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            OptionButton(
                              "Cancel".tr(),
                              onTap: () {
                                Navigator.of(context).pop(null);
                              },
                              lineHeight: 1.2,
                              padding: EdgeInsets.symmetric(
                                  vertical: 10.h, horizontal: 20.w),
                              fontSize: 20.sp,
                              style: "primary",
                            ),
                            OptionButton(
                              "Done".tr(),
                              onTap: () {
                                Navigator.of(context)
                                    .pop(textEditingController.text);
                              },
                              lineHeight: 1.2,
                              padding: EdgeInsets.symmetric(
                                  vertical: 10.h, horizontal: 20.w),
                              fontSize: 20.sp,
                              style: "primary",
                            ),
                          ],
                        ))
                      ],
                    ),
                  ],
                ),
              ),
            ]),
          ),
        );
      },
      context: mainContext!,
    );
    return resault;
  }

  @override
  Future<PricedNote?> noteDialogWithPrice({String initValue = ""}) async {
    String note = "";
    double price = 0;
    PricedNote? resault = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      useRootNavigator: false,
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Dialog(
            backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
            child: Container(
              height: 390.h,
              width: 600.w,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(20.r))),
              child: Column(children: [
                Container(
                  padding: EdgeInsets.all(20.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Add Short Note".tr(),
                        style: TextStyle(
                            fontSize: 18.sp, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    children: [
                      CustomTextArea(
                        hint: "Enter text ...".tr(),
                        callback: ((p0) {
                          note = p0;
                        }),
                      ),
                      SizedBox(
                        height: 15.h,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Column(
                      children: [
                        CustomDigitsField(
                            hint: "0.000",
                            callback: ((p0) {
                              price = p0;
                            }),
                            keypadType: KeyPadType.price),
                        SizedBox(
                          height: 15.h,
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 85.h,
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  decoration: const BoxDecoration(
                      color: Color.fromRGBO(238, 238, 238, 1),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20))),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              OptionButton(
                                "Cancel".tr(),
                                onTap: () {
                                  Navigator.of(context).pop(null);
                                },
                                lineHeight: 1.2,
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.h, horizontal: 20.w),
                                fontSize: 20.sp,
                                style: "primary",
                              ),
                              OptionButton(
                                "Done".tr(),
                                onTap: () {
                                  Navigator.of(context)
                                      .pop(PricedNote(note, price));
                                },
                                lineHeight: 1.2,
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.h, horizontal: 20.w),
                                fontSize: 20.sp,
                                style: "primary",
                              ),
                            ],
                          ))
                        ],
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: mainContext!,
      pageBuilder: (context, animation1, animation2) {
        return const Text("");
      },
    );

    return resault;
  }

  @override
  Future<double?> numberDialog(String title) async {
    late TextEditingController textEditingController = TextEditingController();
    late FocusNode focus = FocusNode();

    double? res = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Dialog(
            backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
            child: LayoutBuilder(builder: (context, constraints) {
              double dialogWidth = constraints.minWidth;
              double keyWidth = ((dialogWidth - 40.w) / 3);
              double dialogHeight = 60 + //cancel enter button height
                  60.h + // textbox height
                  45.h + // margin between buttons
                  30 + // enter your password height
                  10 + //cancel enter margin top
                  10.h + // enter your password margin
                  20.h + //container vertical padding
                  30.h + //textbox padding
                  (keyWidth * 4); // for row of buttons
              return Container(
                width: dialogWidth,
                height: dialogHeight,
                padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: WidgetUtilts.currentSkin.bgColor,
                ),
                child: Column(children: [
                  Container(
                    height: 30,
                    margin: EdgeInsets.only(bottom: 20.h, top: 10.h),
                    child: Text(
                      title,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.w700,
                          height: 1.5.h),
                    ),
                  ),
                  KeyPad(
                    (txt) {
                      textEditingController.text = txt;
                      focus.requestFocus();
                    },
                    keyHeight: keyWidth,
                    light: false,
                    keypadType: KeyPadType.number,
                    enableKeyboardListner: true,
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 10.h),
                    child: Row(
                      children: [
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Cancel".tr(),
                            onTap: () {
                              Navigator.of(context).pop(null);
                            },
                            fontSize: 30.sp,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Done".tr(),
                            onTap: () {
                              double? x =
                                  double.tryParse(textEditingController.text);
                              Navigator.of(context).pop(x);
                            },
                            fontSize: 30.sp,
                          ),
                        )
                      ],
                    ),
                  )
                ]),
              );
            }),
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: mainContext!,
      pageBuilder: (context, animation1, animation2) {
        return const Text("");
      },
    );
    return res;
  }

  @override
  Future<double?> priceDialog(String title) async {
    late TextEditingController textEditingController = TextEditingController();
    late FocusNode focus = FocusNode();

    double? res = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Dialog(
            backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
            child: LayoutBuilder(builder: (context, constraints) {
              double dialogWidth = constraints.minWidth;
              double keyWidth = ((dialogWidth - 40.w) / 3);
              double dialogHeight = 60 + //cancel enter button height
                  60.h + // textbox height
                  45.h + // margin between buttons
                  30 + // enter your password height
                  10 + //cancel enter margin top
                  10.h + // enter your password margin
                  20.h + //container vertical padding
                  30.h + //textbox padding
                  (keyWidth * 4); // for row of buttons
              return Container(
                width: dialogWidth,
                height: dialogHeight,
                padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: WidgetUtilts.currentSkin.bgColor,
                ),
                child: Column(children: [
                  Container(
                    height: 30,
                    margin: EdgeInsets.only(bottom: 20.h, top: 10.h),
                    child: Text(
                      title,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.w700,
                          height: 1.5.h),
                    ),
                  ),
                  KeyPad(
                    (txt) {
                      textEditingController.text = txt;
                      focus.requestFocus();
                    },
                    keyHeight: keyWidth,
                    light: false,
                    keypadType: KeyPadType.price,
                    enableKeyboardListner: true,
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 10.h),
                    child: Row(
                      children: [
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Cancel".tr(),
                            onTap: () {
                              Navigator.of(context).pop(null);
                            },
                            fontSize: 30.sp,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Done".tr(),
                            onTap: () {
                              double? x =
                                  double.tryParse(textEditingController.text);
                              Navigator.of(context).pop(x);
                            },
                            fontSize: 30.sp,
                          ),
                        )
                      ],
                    ),
                  )
                ]),
              );
            }),
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: mainContext!,
      pageBuilder: (context, animation1, animation2) {
        return const Text("");
      },
    );
    return res;
  }

  @override
  Future<String> phoneDialog(String title) async {
    late TextEditingController textEditingController = TextEditingController();
    late FocusNode focus = FocusNode();

    String? res = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Dialog(
            backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
            child: LayoutBuilder(builder: (context, constraints) {
              double dialogWidth = constraints.minWidth;
              double keyWidth = ((dialogWidth - 40.w) / 3);
              double dialogHeight = 60 + //cancel enter button height
                  60.h + // textbox height
                  45.h + // margin between buttons
                  30 + // enter your password height
                  10 + //cancel enter margin top
                  10.h + // enter your password margin
                  20.h + //container vertical padding
                  30.h + //textbox padding
                  (keyWidth * 4); // for row of buttons
              return Container(
                width: dialogWidth,
                height: dialogHeight,
                padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: WidgetUtilts.currentSkin.bgColor,
                ),
                child: Column(children: [
                  Container(
                    height: 30,
                    margin: EdgeInsets.only(bottom: 20.h, top: 10.h),
                    child: Text(
                      title,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25.sp,
                          fontWeight: FontWeight.w700,
                          height: 1.5.h),
                    ),
                  ),
                  KeyPad(
                    (txt) {
                      textEditingController.text = txt;
                      focus.requestFocus();
                    },
                    keyHeight: keyWidth,
                    light: false,
                    keypadType: KeyPadType.number,
                    enableKeyboardListner: true,
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 10.h),
                    child: Row(
                      children: [
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Cancel".tr(),
                            onTap: () {
                              Navigator.of(context).pop("");
                            },
                            fontSize: 30.sp,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: KeyButton(
                            height: 60,
                            "Done".tr(),
                            onTap: () {
                              Navigator.of(context)
                                  .pop(textEditingController.text);
                            },
                            fontSize: 30.sp,
                          ),
                        )
                      ],
                    ),
                  )
                ]),
              );
            }),
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: mainContext!,
      pageBuilder: (context, animation1, animation2) {
        return const Text("");
      },
    );
    if (res == null) return "";
    return res;
  }

  @override
  Future<DateTime?> dateTimePicker(String title) async {
    DateTime selectedDateTime = DateTime.now();

    DateTime? res = await showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      useRootNavigator: false,
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Dialog(
            backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
            child: Container(
              height: 310.h,
              width: 400.w,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(20.r))),
              child: Column(children: [
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
                  child: Text(
                    title,
                    textAlign: TextAlign.center,
                    style:
                        TextStyle(fontSize: 22.sp, fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 11.h),
                  child: Row(children: [
                    Container(
                      padding: EdgeInsets.only(right: 8.w),
                      child: Text(
                        "Date".tr(),
                        textAlign: TextAlign.start,
                        style: TextStyle(fontSize: 25.sp, height: 1.5),
                      ),
                    ),
                    Expanded(
                      child: CustomDateField(
                        hint: 'Date'.tr(),
                        initValue: selectedDateTime,
                        callback: (value) {
                          if (value != null) {
                            selectedDateTime = DateTime(
                                value.year,
                                value.month,
                                value.day,
                                selectedDateTime.hour,
                                selectedDateTime.minute);
                          }
                        },
                      ),
                    ),
                  ]),
                ),
                Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 11.h),
                  child: Row(children: [
                    Container(
                      padding: EdgeInsets.only(right: 8.w),
                      child: Text(
                        "Time".tr(),
                        textAlign: TextAlign.start,
                        style: TextStyle(fontSize: 25.sp, height: 1.5),
                      ),
                    ),
                    Expanded(
                      child: CustomTimeField(
                        hint: 'Time'.tr(),
                        initValue: selectedDateTime,
                        callback: (value) {
                          if (value != null) {
                            selectedDateTime = DateTime(
                                selectedDateTime.year,
                                selectedDateTime.month,
                                selectedDateTime.day,
                                value.hour,
                                value.minute);
                          }
                        },
                      ),
                    ),
                  ]),
                ),
                Container(
                  height: 85.h,
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  decoration: const BoxDecoration(
                      color: Color.fromRGBO(238, 238, 238, 1),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20))),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              OptionButton(
                                "Cancel".tr(),
                                lineHeight: 1.2,
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.h, horizontal: 20.w),
                                fontSize: 20.sp,
                                style: "danger",
                                onTap: () {
                                  Navigator.of(context).pop(null);
                                },
                              ),
                              OptionButton(
                                "Select".tr(),
                                lineHeight: 1.2,
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.h, horizontal: 20.w),
                                fontSize: 20.sp,
                                style: "primary",
                                onTap: () {
                                  Navigator.of(context).pop(selectedDateTime);
                                },
                              )
                            ],
                          ))
                        ],
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: '',
      context: mainContext!,
      pageBuilder: (context, animation1, animation2) {
        return const Text("");
      },
    );
    if (res == null) return null;
    return res;
  }

  @override
  Future<Menu?> showMenuList(List<Menu> menus) async {
    Menu? menu = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 350.h,
                width: 350.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Text(
                      "Change Menu".tr(),
                      style: TextStyle(
                          fontSize: 22.sp, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      padding: EdgeInsets.all(8.w),
                      itemCount: menus.length,
                      itemBuilder: (ctx, index) {
                        return InkWell(
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(
                              color: WidgetUtilts.currentSkin.primaryColor,
                              borderRadius: BorderRadius.circular(10.r),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  menus[index].name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  ),
                                ),
                                Text(
                                  "${menus[index].startAt == null ? "" : DateFormat('HH:mm').format(menus[index].startAt!)}-${menus[index].endAt == null ? "" : DateFormat('HH:mm').format(menus[index].endAt!)}",
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          onTap: () {
                            Navigator.of(context).pop(menus[index]);
                          },
                        );
                      },
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });
    return menu;
  }

  @override
  Future<ProductBatch?> batchedItem(List<ProductBatch> batches) async {
    final StreamController<String> searchController =
        StreamController<String>.broadcast();
    String filterText = "";

    ProductBatch? resault = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 600.h,
                width: 800.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Choose a Batch".tr(),
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: CustomTextField(
                        hint: 'Search ...'.tr(),
                        focus: true,
                        callback: (value) {
                          filterText = value;
                          searchController.add(value);
                        }),
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: StreamBuilder<Object>(
                          stream: searchController.stream,
                          builder: (context, snapshot) {
                            List<DataRow> customerTableRow = [];
                            List<ProductBatch> batchesList = [];
                            if (filterText == "") {
                              batchesList = batches;
                            } else {
                              batchesList = batches
                                  .where((f) => f.batch
                                      .toLowerCase()
                                      .contains(filterText.toLowerCase()))
                                  .toList();
                            }

                            for (var batch in batchesList) {
                              customerTableRow.add(
                                DataRow(
                                  onSelectChanged: (selected) {},
                                  cells: <DataCell>[
                                    DataCell(Text(
                                      batch.batch.toString(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          color: Colors.black,
                                          height: 1),
                                    )),
                                    DataCell(Text(
                                      batch.expireDate.toString(),
                                      style: TextStyle(
                                          fontSize: 18.sp, color: Colors.black),
                                    )),
                                    DataCell(SizedBox(
                                      height: 45.h,
                                      child: OptionButton(
                                        "Select".tr(),
                                        lineHeight: 1.2,
                                        padding: EdgeInsets.symmetric(
                                            vertical: 10.h, horizontal: 20.w),
                                        fontSize: 20.sp,
                                        style: "primary",
                                        onTap: () {
                                          Navigator.of(context).pop(batch);
                                        },
                                      ),
                                    )),
                                  ],
                                ),
                              );
                            }

                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 20.h),
                              child: LayoutBuilder(
                                  builder: (context, constraints) {
                                double availableWidth =
                                    constraints.maxWidth - 49;
                                return DataTable2(
                                  sortColumnIndex: 0,
                                  sortAscending: true,
                                  showCheckboxColumn: false,
                                  dataRowHeight: 60.h,
                                  headingRowHeight: 40,
                                  columnSpacing: 1,
                                  columns: <DataColumn2>[
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.45,
                                      label: Text(
                                        "Name".tr(),
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.4,
                                      label: Text(
                                        "Expiry Date".tr(),
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.15,
                                      label: Text(
                                        "",
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                  ],
                                  rows: <DataRow>[...customerTableRow],
                                );
                              }),
                            );
                          }),
                    ),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  onTap: () {
                                    Navigator.of(context).pop(null);
                                  },
                                  style: "primary",
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });

    searchController.close();
    return resault;
  }

  @override
  Future<ProductSerial?> serializedItem(List<ProductSerial> serials) async {
    final StreamController<String> searchController =
        StreamController<String>.broadcast();
    String filterText = "";

    ProductSerial? resault = await showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        useRootNavigator: false,
        transitionBuilder: (context, a1, a2, widget) {
          final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
          return Transform(
            transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
            child: Dialog(
              backgroundColor: const Color.fromRGBO(0, 0, 0, 0),
              child: Container(
                height: 600.h,
                width: 800.w,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20.r))),
                child: Column(children: [
                  Container(
                    padding: EdgeInsets.all(20.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Choose a Serial".tr(),
                          style: TextStyle(
                              fontSize: 22.sp, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: CustomTextField(
                        hint: 'Search ...'.tr(),
                        focus: true,
                        callback: (value) {
                          filterText = value;
                          searchController.add(value);
                        }),
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: StreamBuilder<Object>(
                          stream: searchController.stream,
                          builder: (context, snapshot) {
                            List<DataRow> customerTableRow = [];
                            List<ProductSerial> serialList = [];
                            if (filterText == "") {
                              serialList = serials;
                            } else {
                              serialList = serials
                                  .where((f) => f.serial
                                      .toLowerCase()
                                      .contains(filterText.toLowerCase()))
                                  .toList();
                            }

                            for (var serial in serialList) {
                              customerTableRow.add(
                                DataRow(
                                  onSelectChanged: (selected) {},
                                  cells: <DataCell>[
                                    DataCell(Text(
                                      serial.serial.toString(),
                                      style: TextStyle(
                                          fontSize: 18.sp,
                                          color: Colors.black,
                                          height: 1),
                                    )),
                                    DataCell(Text(
                                      serial.status.toString(),
                                      style: TextStyle(
                                          fontSize: 18.sp, color: Colors.black),
                                    )),
                                    DataCell(SizedBox(
                                      height: 45.h,
                                      child: serial.status == "Available"
                                          ? OptionButton(
                                              "Select".tr(),
                                              lineHeight: 1.2,
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 10.h,
                                                  horizontal: 20.w),
                                              fontSize: 20.sp,
                                              style: "primary",
                                              onTap: () {
                                                Navigator.of(context)
                                                    .pop(serial);
                                              },
                                            )
                                          : const SizedBox(),
                                    )),
                                  ],
                                ),
                              );
                            }

                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 20.h),
                              child: LayoutBuilder(
                                  builder: (context, constraints) {
                                double availableWidth =
                                    constraints.maxWidth - 49;
                                return DataTable2(
                                  sortColumnIndex: 0,
                                  sortAscending: true,
                                  showCheckboxColumn: false,
                                  dataRowHeight: 60.h,
                                  headingRowHeight: 40,
                                  columnSpacing: 1,
                                  columns: <DataColumn2>[
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.65,
                                      label: Text(
                                        "Name".tr(),
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.19,
                                      label: Text(
                                        "Status".tr(),
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                    DataColumn2(
                                      fixedWidth: availableWidth * 0.16,
                                      label: Text(
                                        "",
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            height: 1.5.h,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      onSort:
                                          (int columnIndex, bool ascending) {},
                                    ),
                                  ],
                                  rows: <DataRow>[...customerTableRow],
                                );
                              }),
                            );
                          }),
                    ),
                  ),
                  Container(
                    height: 85.h,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: const BoxDecoration(
                        color: Color.fromRGBO(238, 238, 238, 1),
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                OptionButton(
                                  "Cancel".tr(),
                                  lineHeight: 1.2,
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10.h, horizontal: 20.w),
                                  fontSize: 20.sp,
                                  onTap: () {
                                    Navigator.of(context).pop(null);
                                  },
                                  style: "primary",
                                ),
                              ],
                            ))
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: mainContext!,
        pageBuilder: (context, animation1, animation2) {
          return const Text("");
        });

    searchController.close();
    return resault;
  }

  @override
  Future<String?> voidReasonDialog(
      {List<String> reasons = const ["Customer Return", "Damaged"]}) async {
    TextEditingController textEditingController = TextEditingController();

    FocusNode focus = FocusNode();

    List<Widget> reasonsBtns = [];
    for (var element in reasons) {
      reasonsBtns.add(
        InkWell(
          onTap: () {
            textEditingController.text = element;
          },
          child: Container(
            margin: EdgeInsets.all(5.h),
            padding: EdgeInsets.symmetric(horizontal: 15.w),
            decoration: BoxDecoration(
              color: const Color(0xFF4F9AFF),
              borderRadius: BorderRadiusDirectional.only(
                  topStart: Radius.circular(10.r),
                  bottomEnd: Radius.circular(10.r)),
            ),
            child: Text(element,
                style: TextStyle(color: Colors.white, fontSize: 18.sp)),
          ),
        ),
      );
    }
    return null;
  }

  @override
  hideLoading() {
    if (isLoading) Navigator.of(mainContext!).pop();
  }

  bool isLoading = false;
  @override
  showLoading() async {
    if (isLoading) return;
    isLoading = true;
    await showDialog<void>(
        context: mainContext!,
        barrierDismissible: false,
        builder: (BuildContext context) {
          // return SimpleDialog(
          //   elevation: 0.0,
          //   backgroundColor: Colors.transparent, // can change this to your prefered color
          //   children: <Widget>[
          //     Container(
          //       width: 200,
          //       height: 170,
          //       decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(20.r))),
          //       child: Column(
          //         mainAxisAlignment: MainAxisAlignment.center,
          //         children: [
          //           const CircularProgressIndicator(),
          //           SizedBox(height: 20.h),
          //           Text("Loading", style: TextStyle(fontSize: 30.sp)),
          //         ],
          //       ),
          //     )
          //   ],
          // );
          // if (!Utilts().checkConnection()) {
          //   Fluttertoast.showToast(msg: "No internet connection");
          // }
          return Material(
              color:
                  Colors.transparent, // can change this to your prefered color
              child: Center(
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(20.r))),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const CircularProgressIndicator(),
                      SizedBox(height: 15.h),
                      Text(
                        "Loading",
                        style: TextStyle(fontSize: 20.sp, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ));
        });
    // if (!Utilts().checkConnection()) {
    //   Fluttertoast.showToast(msg: "No internet connection");
    // }
    isLoading = false;
  }
}
