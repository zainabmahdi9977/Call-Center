import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:newcall_center/pages/LoginPage/login.page.dart';
import 'package:newcall_center/pages/MainPage/main.page.dart';
// import 'package:invo/helpers/skins.dart';
// import 'package:invo/helpers/utlits.dart';
// import 'package:window_manager/window_manager.dart';
import 'package:resize/resize.dart';

// import 'package:windows_single_instance/windows_single_instance.dart';

// import 'view/Pages/Main/MainPage.dart';
// import 'package:sentry_flutter/sentry_flutter.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)..badCertificateCallback = (X509Certificate cert, String host, int port) => true;
  }
}

String getType() {
  String type = "web";
  if (Platform.isAndroid) {
    type = "Android";
  } else if (Platform.isIOS) {
    type = "IOS";
  } else if (Platform.isLinux) {
    type = "Linux";
  } else if (Platform.isMacOS) {
    type = "MacOS";
  } else if (Platform.isWindows) {
    type = "Windows";
  }
  return type;
}

Future<void> main(List<String> args) async {
  HttpOverrides.global = MyHttpOverrides();
  WidgetsFlutterBinding.ensureInitialized();

  // await EasyLocalization.ensureInitialized();
  runApp(const App());

  // EasyLocalization(
  //     supportedLocales: const [Locale('en', ''), Locale('ar', '')],
  //     path: 'assets/i18n', // <-- change the path of the translation files
  //     startLocale: const Locale('en', ''),
  //     fallbackLocale: const Locale('en', ''),
  //     child: App(),
  //   ),
}

class App extends StatefulWidget {
  // final StreamController<Skin> themeController = StreamController<Skin>();

  const App({Key? key}) : super(key: key);

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    double minWidth = MediaQuery.of(context).size.width;
    double minHeight = MediaQuery.of(context).size.height;

    double? sizeWidth;
    double? sizeHeight;

    setState(() {
      if (minWidth < 1024.0 && minHeight < 768) {
        sizeWidth == 1024;
        sizeHeight == 768;
      } else {
        sizeWidth == MediaQuery.of(context).size.width;
        sizeHeight == MediaQuery.of(context).size.height;
      }
    });

    return Resize(
        size: const Size(1920, 1080),
        builder: () {
          return MaterialApp(
              debugShowCheckedModeBanner: false,
              // routeInformationParser: AppRoutes().router.routeInformationParser,
              // routerDelegate: AppRoutes().router.routerDelegate,
              // localizationsDelegates: context.localizationDelegates,
              // supportedLocales: context.supportedLocales,
              // locale: context.locale,
              title: 'Invo App',
              // builder: (context, child) {
              //   return const LoginPage();
              //   //  return AppRoutes().router.builder(context, child);
              // },
              initialRoute: "Login",
              routes: {
                'Login': (context) {
                  return const LoginPage();
                },
                'Main': (context) {
                  return Center(child: SizedBox(width: sizeWidth, height: sizeHeight, child: const MainPage()));
                }
              });
          // return StreamBuilder<Skin>(
          //     key: Utilts.themeKey,
          //     stream: themeController.stream,
          //     initialData: Utilts.skins[0],
          //     builder: (context, snapshot) {
          //       Utilts.appContext = context;
          //       return MaterialApp(
          //         debugShowCheckedModeBanner: false,
          //         navigatorKey: Utilts.rootNavigationKey,
          //         localizationsDelegates: context.localizationDelegates,
          //         supportedLocales: context.supportedLocales,
          //         locale: context.locale,
          //         title: 'Invo App',
          //         initialRoute: 'SplashScreen',
          //         routes: {
          //           'Login': (context) => const LoginPage(
          //                 autoConnect: true,
          //               ),
          //           'Main': (context) {
          //             return const MainPage();
          //           },
          //           'SplashScreen': (context) {
          //             return const SplashScreen();
          //           },
          //         },
          //         theme: ThemeData(
          //           fontFamily: 'Cairo',
          //         ),
          //       );
          //     });
        });
  }
}
